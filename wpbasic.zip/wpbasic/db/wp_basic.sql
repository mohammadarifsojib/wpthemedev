-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2022 at 07:17 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wp_basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_commentmeta`
--

CREATE TABLE `wpbasic_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_comments`
--

CREATE TABLE `wpbasic_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_comments`
--

INSERT INTO `wpbasic_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-07-08 15:39:17', '2022-07-08 15:39:17', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_links`
--

CREATE TABLE `wpbasic_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_options`
--

CREATE TABLE `wpbasic_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_options`
--

INSERT INTO `wpbasic_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wpbasic', 'yes'),
(2, 'home', 'http://localhost/wpbasic', 'yes'),
(3, 'blogname', 'Wordpress Basic Theme Development', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'parvezsani191@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:92:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=43&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:25:\"fakerpress/fakerpress.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'wpbasic', 'yes'),
(41, 'stylesheet', 'wpbasic', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '43', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1672846757', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wpbasic_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '2', 'no'),
(103, 'widget_block', 'a:16:{i:2;a:1:{s:7:\"content\";s:67:\"<!-- wp:heading -->\n<h2>Theme Development</h2>\n<!-- /wp:heading -->\";}i:3;a:1:{s:7:\"content\";s:370:\"<!-- wp:paragraph {\"className\":\"mb-0\"} -->\n<p class=\"mb-0\">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id animi laudantium beatae dolorum rem tenetur voluptatibus cupiditate unde ea, quidem. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id animi laudantium beatae dolorum rem tenetur voluptatibus cupiditate unde ea, </p>\n<!-- /wp:paragraph -->\";}i:4;a:1:{s:7:\"content\";s:62:\"<!-- wp:heading -->\n<h2>Useful Links</h2>\n<!-- /wp:heading -->\";}i:6;a:1:{s:7:\"content\";s:62:\"<!-- wp:heading -->\n<h2>Social Links</h2>\n<!-- /wp:heading -->\";}i:7;a:1:{s:7:\"content\";s:743:\"<!-- wp:social-links {\"customIconColor\":\"#3898db\",\"iconColorValue\":\"#3898db\",\"customIconBackgroundColor\":\"#bdefdb\",\"iconBackgroundColorValue\":\"#bdefdb\",\"openInNewTab\":true,\"size\":\"has-normal-icon-size\",\"className\":\"is-style-default\",\"layout\":{\"type\":\"flex\",\"justifyContent\":\"left\",\"flexWrap\":\"nowrap\"}} -->\n<ul class=\"wp-block-social-links has-normal-icon-size has-icon-color has-icon-background-color is-style-default\"><!-- wp:social-link {\"url\":\"#\",\"service\":\"twitter\"} /-->\n\n<!-- wp:social-link {\"url\":\"#\",\"service\":\"facebook\"} /-->\n\n<!-- wp:social-link {\"url\":\"#\",\"service\":\"youtube\"} /-->\n\n<!-- wp:social-link {\"url\":\"#\",\"service\":\"linkedin\"} /-->\n\n<!-- wp:social-link {\"url\":\"#\",\"service\":\"instagram\"} /--></ul>\n<!-- /wp:social-links -->\";}i:8;a:1:{s:7:\"content\";s:74:\"<!-- wp:heading {\"level\":4} -->\n<h4>Working Time</h4>\n<!-- /wp:heading -->\";}i:9;a:1:{s:7:\"content\";s:134:\"<!-- wp:list -->\n<ul><li>Sunday - Monday : 10:00AM - 05:00PM</li><li>Tuesday - Thursday: 09:00AM - 03:00PM</li></ul>\n<!-- /wp:list -->\";}i:12;a:1:{s:7:\"content\";s:91:\"<!-- wp:search {\"label\":\"Search\",\"placeholder\":\"Type your mind\",\"buttonText\":\"Search\"} /-->\";}i:13;a:1:{s:7:\"content\";s:72:\"<!-- wp:heading {\"level\":3} -->\n<h3>Categories</h3>\n<!-- /wp:heading -->\";}i:14;a:1:{s:7:\"content\";s:47:\"<!-- wp:categories {\"showPostCounts\":true} /-->\";}i:15;a:1:{s:7:\"content\";s:71:\"<!-- wp:heading {\"level\":3} -->\n<h3>Tag Lists</h3>\n<!-- /wp:heading -->\";}i:16;a:1:{s:7:\"content\";s:76:\"<!-- wp:tag-cloud {\"showTagCounts\":true,\"className\":\"is-style-default\"} /-->\";}i:17;a:1:{s:7:\"content\";s:62:\"<!-- wp:heading -->\n<h2>Recent Posts</h2>\n<!-- /wp:heading -->\";}i:18;a:1:{s:7:\"content\";s:142:\"<!-- wp:latest-posts {\"displayFeaturedImage\":true,\"featuredImageSizeWidth\":75,\"featuredImageSizeHeight\":75,\"addLinkToFeaturedImage\":true} /-->\";}i:19;a:1:{s:7:\"content\";s:65:\"<!-- wp:heading -->\n<h2>Important Links</h2>\n<!-- /wp:heading -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:10:{s:19:\"wp_inactive_widgets\";a:0:{}s:11:\"r-sidebar-1\";a:1:{i:0;s:8:\"block-12\";}s:11:\"r-sidebar-2\";a:2:{i:0;s:8:\"block-13\";i:1;s:8:\"block-14\";}s:11:\"r-sidebar-3\";a:2:{i:0;s:8:\"block-15\";i:1;s:8:\"block-16\";}s:11:\"r-sidebar-4\";a:2:{i:0;s:8:\"block-17\";i:1;s:8:\"block-18\";}s:8:\"footer-1\";a:2:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";}s:8:\"footer-2\";a:2:{i:0;s:7:\"block-4\";i:1;s:10:\"nav_menu-2\";}s:8:\"footer-3\";a:2:{i:0;s:8:\"block-19\";i:1;s:10:\"nav_menu-3\";}s:8:\"footer-4\";a:4:{i:0;s:7:\"block-6\";i:1;s:7:\"block-7\";i:2;s:7:\"block-8\";i:3;s:7:\"block-9\";}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:8:{i:1658338758;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1658374758;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1658374770;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1658417958;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1658417970;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1658417977;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1658590758;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'nonce_key', 'etninr|zwl`c?tCqIeQz@x>5DW5RzE$Iz*;/C2~-,v`A:?#J!9g6Y#I^z/f~x4:^', 'no'),
(116, 'nonce_salt', ':~Ywo80^gq(2<A)_ehV* ?*7L>;U[wnk,!{&%zNMTE&Cp_Qo{!M{DJTE;W192m77', 'no'),
(117, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'widget_nav_menu', 'a:3:{i:2;a:1:{s:8:\"nav_menu\";i:16;}i:3;a:1:{s:8:\"nav_menu\";i:17;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(121, 'recovery_keys', 'a:0:{}', 'yes'),
(124, 'theme_mods_twentytwentytwo', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1657294898;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(127, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(133, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1658334915;s:7:\"checked\";a:4:{s:12:\"twentytwenty\";s:3:\"2.0\";s:15:\"twentytwentyone\";s:3:\"1.6\";s:15:\"twentytwentytwo\";s:3:\"1.2\";s:7:\"wpbasic\";s:0:\"\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.2.0.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.6.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}s:15:\"twentytwentytwo\";a:6:{s:5:\"theme\";s:15:\"twentytwentytwo\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentytwo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentytwo.1.2.zip\";s:8:\"requires\";s:3:\"5.9\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(134, 'auth_key', '^bT]5875M/,dZzs<b`7^!s]@,1weHwf:s%-vb,jiX>TWXT5&aZGhSl3;;2$}>|2)', 'no'),
(135, 'auth_salt', '.O6h(Z6J.O=C0k>=$Sb<ZhJl91-S;p.:k2J7x4eR*YG<~8T}|?b7k],*:`e@h8jt', 'no'),
(136, 'logged_in_key', 'dN:4Bi1~ph1 A6=u:XJ`Di(vS,J;zyU8>)aIg%fI5dU V*]mn8GLi*U]k9f/WS-_', 'no'),
(137, 'logged_in_salt', 'g[dS+361F-y3+d_Zr+IUiN{hl3d8,l=vw2ZbZZSI@^l hJGZ!-l`L*|HTS7TfRNB', 'no'),
(156, 'finished_updating_comment_type', '1', 'yes'),
(157, 'current_theme', 'WPBasic', 'yes'),
(158, 'theme_mods_wpbasic', 'a:6:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:9;s:11:\"footer_menu\";i:16;}s:18:\"custom_css_post_id\";i:-1;s:12:\"header_image\";s:64:\"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1658121619;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:1:{i:0;s:12:\"foo_widget-2\";}s:9:\"sidebar-1\";a:0:{}}}s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:59;s:3:\"url\";s:64:\"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\";s:13:\"thumbnail_url\";s:64:\"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\";s:6:\"height\";i:50;s:5:\"width\";i:150;}}', 'yes'),
(159, 'theme_switched', '', 'yes'),
(160, 'recovery_mode_email_last_sent', '1657295080', 'yes'),
(191, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1658334913;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:1:{s:25:\"fakerpress/fakerpress.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:24:\"w.org/plugins/fakerpress\";s:4:\"slug\";s:10:\"fakerpress\";s:6:\"plugin\";s:25:\"fakerpress/fakerpress.php\";s:11:\"new_version\";s:5:\"0.5.3\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/fakerpress/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/fakerpress.0.5.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:63:\"https://ps.w.org/fakerpress/assets/icon-256x256.png?rev=1846090\";s:2:\"1x\";s:55:\"https://ps.w.org/fakerpress/assets/icon.svg?rev=1846090\";s:3:\"svg\";s:55:\"https://ps.w.org/fakerpress/assets/icon.svg?rev=1846090\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/fakerpress/assets/banner-1544x500.png?rev=1152002\";s:2:\"1x\";s:65:\"https://ps.w.org/fakerpress/assets/banner-772x250.png?rev=1152002\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}}}', 'no'),
(192, 'recently_activated', 'a:0:{}', 'yes'),
(193, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(251, '_transient_health-check-site-status-result', '{\"good\":15,\"recommended\":3,\"critical\":1}', 'yes'),
(310, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(311, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(336, 'widget_foo_widget', 'a:2:{i:2;a:1:{s:5:\"title\";s:9:\"New title\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(346, 'db_upgraded', '', 'yes'),
(348, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-6.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-6.0.1-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.0.1\";s:7:\"version\";s:5:\"6.0.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1658334913;s:15:\"version_checked\";s:5:\"6.0.1\";s:12:\"translations\";a:0:{}}', 'no'),
(349, 'can_compress_scripts', '1', 'no'),
(370, '_site_transient_timeout_browser_a0909810a6d132832e28ef6da18ec77c', '1658504587', 'no'),
(371, '_site_transient_browser_a0909810a6d132832e28ef6da18ec77c', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"103.0.0.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(372, '_site_transient_timeout_php_check_75809dde56e3fe2c2fb740f1b55807ac', '1658504590', 'no'),
(373, '_site_transient_php_check_75809dde56e3fe2c2fb740f1b55807ac', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(376, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(419, '_site_transient_timeout_browser_098b90df11ae170519153ebe0bd756f2', '1658548358', 'no'),
(420, '_site_transient_browser_098b90df11ae170519153ebe0bd756f2', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:5:\"102.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:32:\"https://www.mozilla.org/firefox/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(432, 'theme_mods_wpblock', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1658122172;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:0:{}}}}', 'yes'),
(709, 'category_children', 'a:0:{}', 'yes'),
(730, '_site_transient_timeout_theme_roots', '1658336713', 'no'),
(731, '_site_transient_theme_roots', 'a:4:{s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";s:15:\"twentytwentytwo\";s:7:\"/themes\";s:7:\"wpbasic\";s:7:\"/themes\";}', 'no'),
(777, '_transient_timeout_global_styles_wpbasic', '1658337323', 'no'),
(778, '_transient_global_styles_wpbasic', 'body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url(\'#wp-duotone-dark-grayscale\');--wp--preset--duotone--grayscale: url(\'#wp-duotone-grayscale\');--wp--preset--duotone--purple-yellow: url(\'#wp-duotone-purple-yellow\');--wp--preset--duotone--blue-red: url(\'#wp-duotone-blue-red\');--wp--preset--duotone--midnight: url(\'#wp-duotone-midnight\');--wp--preset--duotone--magenta-yellow: url(\'#wp-duotone-magenta-yellow\');--wp--preset--duotone--purple-green: url(\'#wp-duotone-purple-green\');--wp--preset--duotone--blue-orange: url(\'#wp-duotone-blue-orange\');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_postmeta`
--

CREATE TABLE `wpbasic_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_postmeta`
--

INSERT INTO `wpbasic_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_wp_trash_meta_status', 'publish'),
(4, 1, '_wp_trash_meta_time', '1657294790'),
(5, 1, '_wp_desired_post_slug', 'hello-world'),
(6, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(7, 3, '_wp_trash_meta_status', 'draft'),
(8, 3, '_wp_trash_meta_time', '1657294796'),
(9, 3, '_wp_desired_post_slug', 'privacy-policy'),
(10, 2, '_wp_trash_meta_status', 'publish'),
(11, 2, '_wp_trash_meta_time', '1657294796'),
(12, 2, '_wp_desired_post_slug', 'sample-page'),
(16, 12, '_wp_attached_file', '2022/07/1558ea75-72f7-3e32-9023-33d3f767423b.jpg'),
(17, 12, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1218;s:6:\"height\";i:812;s:4:\"file\";s:48:\"2022/07/1558ea75-72f7-3e32-9023-33d3f767423b.jpg\";s:8:\"filesize\";i:87068;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(18, 12, 'fakerpress_flag', '1'),
(19, 12, '_fakerpress_orginal_url', 'https://picsum.photos/1218/812/?random'),
(20, 13, 'fakerpress_flag', '1'),
(21, 14, '_wp_attached_file', '2022/07/2854de4e-e406-3a1c-8ac4-2b3dcb9b40b3.jpg'),
(22, 14, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1128;s:6:\"height\";i:752;s:4:\"file\";s:48:\"2022/07/2854de4e-e406-3a1c-8ac4-2b3dcb9b40b3.jpg\";s:8:\"filesize\";i:92470;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(23, 14, 'fakerpress_flag', '1'),
(24, 14, '_fakerpress_orginal_url', 'https://picsum.photos/1128/752/?random'),
(25, 13, '_thumbnail_id', '14'),
(26, 15, '_wp_attached_file', '2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg'),
(27, 15, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1121;s:6:\"height\";i:747;s:4:\"file\";s:48:\"2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\";s:8:\"filesize\";i:39380;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(28, 15, 'fakerpress_flag', '1'),
(29, 15, '_fakerpress_orginal_url', 'https://picsum.photos/1121/747/?random'),
(30, 16, 'fakerpress_flag', '1'),
(31, 17, '_wp_attached_file', '2022/07/669f8e2a-f647-376b-b8a8-a71aebd3b912.jpg'),
(32, 17, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1439;s:6:\"height\";i:959;s:4:\"file\";s:48:\"2022/07/669f8e2a-f647-376b-b8a8-a71aebd3b912.jpg\";s:8:\"filesize\";i:177080;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(33, 17, 'fakerpress_flag', '1'),
(34, 17, '_fakerpress_orginal_url', 'https://picsum.photos/1439/959/?random'),
(35, 16, '_thumbnail_id', '17'),
(36, 18, 'fakerpress_flag', '1'),
(37, 19, '_wp_attached_file', '2022/07/6855cf5a-b58b-3497-9d1f-c044a296c438.jpg'),
(38, 19, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1170;s:6:\"height\";i:780;s:4:\"file\";s:48:\"2022/07/6855cf5a-b58b-3497-9d1f-c044a296c438.jpg\";s:8:\"filesize\";i:68944;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(39, 19, 'fakerpress_flag', '1'),
(40, 19, '_fakerpress_orginal_url', 'https://picsum.photos/1170/780/?random'),
(41, 18, '_thumbnail_id', '19'),
(42, 20, 'fakerpress_flag', '1'),
(43, 21, '_wp_attached_file', '2022/07/7f54bf55-fbba-394a-8332-93b3a03199bd.jpg'),
(44, 21, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1253;s:6:\"height\";i:835;s:4:\"file\";s:48:\"2022/07/7f54bf55-fbba-394a-8332-93b3a03199bd.jpg\";s:8:\"filesize\";i:89620;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(45, 21, 'fakerpress_flag', '1'),
(46, 21, '_fakerpress_orginal_url', 'https://picsum.photos/1253/835/?random'),
(47, 20, '_thumbnail_id', '21'),
(48, 22, 'fakerpress_flag', '1'),
(49, 22, '_thumbnail_id', 'raw'),
(50, 23, 'fakerpress_flag', '1'),
(51, 24, '_wp_attached_file', '2022/07/61158792-202b-3d70-8396-6d6808125a2d.jpg'),
(52, 24, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1300;s:6:\"height\";i:866;s:4:\"file\";s:48:\"2022/07/61158792-202b-3d70-8396-6d6808125a2d.jpg\";s:8:\"filesize\";i:125464;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(53, 24, 'fakerpress_flag', '1'),
(54, 24, '_fakerpress_orginal_url', 'https://picsum.photos/1300/866/?random'),
(55, 23, '_thumbnail_id', '24'),
(56, 25, 'fakerpress_flag', '1'),
(57, 26, '_wp_attached_file', '2022/07/9a7d3578-5dba-39a1-967b-ebd11460db0d.jpg'),
(58, 26, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1149;s:6:\"height\";i:766;s:4:\"file\";s:48:\"2022/07/9a7d3578-5dba-39a1-967b-ebd11460db0d.jpg\";s:8:\"filesize\";i:112658;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(59, 26, 'fakerpress_flag', '1'),
(60, 26, '_fakerpress_orginal_url', 'https://picsum.photos/1149/766/?random'),
(61, 25, '_thumbnail_id', '26'),
(62, 27, 'fakerpress_flag', '1'),
(63, 28, '_wp_attached_file', '2022/07/e6e429ee-b6b2-3ee3-8863-74643f1b73a4.jpg'),
(64, 28, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1218;s:6:\"height\";i:812;s:4:\"file\";s:48:\"2022/07/e6e429ee-b6b2-3ee3-8863-74643f1b73a4.jpg\";s:8:\"filesize\";i:74011;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(65, 28, 'fakerpress_flag', '1'),
(66, 28, '_fakerpress_orginal_url', 'https://picsum.photos/1218/812/?random'),
(67, 27, '_thumbnail_id', '28'),
(68, 29, '_wp_attached_file', '2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg'),
(69, 29, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1315;s:6:\"height\";i:876;s:4:\"file\";s:48:\"2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg\";s:8:\"filesize\";i:115041;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(70, 29, 'fakerpress_flag', '1'),
(71, 29, '_fakerpress_orginal_url', 'https://picsum.photos/1315/876/?random'),
(72, 30, 'fakerpress_flag', '1'),
(73, 31, '_wp_attached_file', '2022/07/6828e009-6770-3891-8af8-7da3ffafba51.jpg'),
(74, 31, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1340;s:6:\"height\";i:893;s:4:\"file\";s:48:\"2022/07/6828e009-6770-3891-8af8-7da3ffafba51.jpg\";s:8:\"filesize\";i:68541;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(75, 31, 'fakerpress_flag', '1'),
(76, 31, '_fakerpress_orginal_url', 'https://picsum.photos/1340/893/?random'),
(77, 30, '_thumbnail_id', '31'),
(78, 32, 'fakerpress_flag', '1'),
(79, 32, '_thumbnail_id', '19'),
(80, 33, '_wp_attached_file', '2022/07/542cb711-4284-3292-8a3c-e2e605c70a99.jpg'),
(81, 33, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1253;s:6:\"height\";i:835;s:4:\"file\";s:48:\"2022/07/542cb711-4284-3292-8a3c-e2e605c70a99.jpg\";s:8:\"filesize\";i:182855;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(82, 33, 'fakerpress_flag', '1'),
(83, 33, '_fakerpress_orginal_url', 'https://picsum.photos/1253/835/?random'),
(84, 34, 'fakerpress_flag', '1'),
(85, 34, '_thumbnail_id', '36'),
(86, 35, 'fakerpress_flag', '1'),
(87, 36, '_wp_attached_file', '2022/07/63334320-9931-340d-954e-284aa1f7bb55.jpg'),
(88, 36, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1123;s:6:\"height\";i:748;s:4:\"file\";s:48:\"2022/07/63334320-9931-340d-954e-284aa1f7bb55.jpg\";s:8:\"filesize\";i:115559;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(89, 36, 'fakerpress_flag', '1'),
(90, 36, '_fakerpress_orginal_url', 'https://picsum.photos/1123/748/?random'),
(91, 35, '_thumbnail_id', '36'),
(92, 37, 'fakerpress_flag', '1'),
(93, 37, '_thumbnail_id', '12'),
(94, 37, '_edit_lock', '1658249756:1'),
(95, 32, '_edit_lock', '1657300784:1'),
(96, 34, '_edit_lock', '1658249784:1'),
(101, 18, '_edit_lock', '1657383370:1'),
(104, 16, '_edit_lock', '1658249733:1'),
(107, 43, '_edit_lock', '1657553165:1'),
(108, 45, '_edit_lock', '1657554062:1'),
(111, 47, '_edit_lock', '1657556300:1'),
(112, 47, '_wp_trash_meta_status', 'publish'),
(113, 47, '_wp_trash_meta_time', '1657556301'),
(114, 48, '_edit_lock', '1657556446:1'),
(115, 48, '_wp_trash_meta_status', 'publish'),
(116, 48, '_wp_trash_meta_time', '1657556452'),
(117, 49, '_wp_trash_meta_status', 'publish'),
(118, 49, '_wp_trash_meta_time', '1657556461'),
(119, 51, '_menu_item_type', 'post_type'),
(120, 51, '_menu_item_menu_item_parent', '0'),
(121, 51, '_menu_item_object_id', '43'),
(122, 51, '_menu_item_object', 'page'),
(123, 51, '_menu_item_target', ''),
(124, 51, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(125, 51, '_menu_item_xfn', ''),
(126, 51, '_menu_item_url', ''),
(137, 53, '_menu_item_type', 'custom'),
(138, 53, '_menu_item_menu_item_parent', '58'),
(139, 53, '_menu_item_object_id', '53'),
(140, 53, '_menu_item_object', 'custom'),
(141, 53, '_menu_item_target', ''),
(142, 53, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(143, 53, '_menu_item_xfn', ''),
(144, 53, '_menu_item_url', '#'),
(146, 54, '_menu_item_type', 'custom'),
(147, 54, '_menu_item_menu_item_parent', '58'),
(148, 54, '_menu_item_object_id', '54'),
(149, 54, '_menu_item_object', 'custom'),
(150, 54, '_menu_item_target', ''),
(151, 54, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(152, 54, '_menu_item_xfn', ''),
(153, 54, '_menu_item_url', '#'),
(155, 55, '_edit_lock', '1657902733:1'),
(156, 57, 'origin', 'theme'),
(157, 58, '_menu_item_type', 'custom'),
(158, 58, '_menu_item_menu_item_parent', '0'),
(159, 58, '_menu_item_object_id', '58'),
(160, 58, '_menu_item_object', 'custom'),
(161, 58, '_menu_item_target', ''),
(162, 58, '_menu_item_classes', 'a:1:{i:0;s:8:\"dropdown\";}'),
(163, 58, '_menu_item_xfn', ''),
(164, 58, '_menu_item_url', '#'),
(166, 51, '_wp_old_date', '2022-07-15'),
(167, 53, '_wp_old_date', '2022-07-15'),
(168, 54, '_wp_old_date', '2022-07-15'),
(169, 59, '_wp_attached_file', '2022/07/vendor-7.jpg'),
(170, 59, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:150;s:6:\"height\";i:50;s:4:\"file\";s:20:\"2022/07/vendor-7.jpg\";s:8:\"filesize\";i:2247;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(171, 59, '_wp_attachment_custom_header_last_used_wpbasic', '1658225070'),
(172, 59, '_wp_attachment_is_custom_header', 'wpbasic'),
(173, 60, '_wp_trash_meta_status', 'publish'),
(174, 60, '_wp_trash_meta_time', '1658225070'),
(175, 61, '_edit_lock', '1658245471:1'),
(176, 63, '_edit_lock', '1658245516:1'),
(177, 65, '_menu_item_type', 'post_type'),
(178, 65, '_menu_item_menu_item_parent', '0'),
(179, 65, '_menu_item_object_id', '63'),
(180, 65, '_menu_item_object', 'page'),
(181, 65, '_menu_item_target', ''),
(182, 65, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(183, 65, '_menu_item_xfn', ''),
(184, 65, '_menu_item_url', ''),
(186, 66, '_menu_item_type', 'post_type'),
(187, 66, '_menu_item_menu_item_parent', '0'),
(188, 66, '_menu_item_object_id', '61'),
(189, 66, '_menu_item_object', 'page'),
(190, 66, '_menu_item_target', ''),
(191, 66, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(192, 66, '_menu_item_xfn', ''),
(193, 66, '_menu_item_url', ''),
(196, 37, '_edit_last', '1'),
(198, 34, '_edit_last', '1'),
(200, 35, '_edit_last', '1'),
(202, 35, '_edit_lock', '1658249795:1'),
(203, 69, '_menu_item_type', 'custom'),
(204, 69, '_menu_item_menu_item_parent', '0'),
(205, 69, '_menu_item_object_id', '69'),
(206, 69, '_menu_item_object', 'custom'),
(207, 69, '_menu_item_target', ''),
(208, 69, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(209, 69, '_menu_item_xfn', ''),
(210, 69, '_menu_item_url', '#'),
(211, 69, '_menu_item_orphaned', '1658335285'),
(212, 70, '_menu_item_type', 'custom'),
(213, 70, '_menu_item_menu_item_parent', '0'),
(214, 70, '_menu_item_object_id', '70'),
(215, 70, '_menu_item_object', 'custom'),
(216, 70, '_menu_item_target', ''),
(217, 70, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(218, 70, '_menu_item_xfn', ''),
(219, 70, '_menu_item_url', '#'),
(220, 70, '_menu_item_orphaned', '1658335294'),
(221, 71, '_menu_item_type', 'custom'),
(222, 71, '_menu_item_menu_item_parent', '0'),
(223, 71, '_menu_item_object_id', '71'),
(224, 71, '_menu_item_object', 'custom'),
(225, 71, '_menu_item_target', ''),
(226, 71, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(227, 71, '_menu_item_xfn', ''),
(228, 71, '_menu_item_url', '#'),
(229, 71, '_menu_item_orphaned', '1658335303'),
(230, 72, '_menu_item_type', 'custom'),
(231, 72, '_menu_item_menu_item_parent', '0'),
(232, 72, '_menu_item_object_id', '72'),
(233, 72, '_menu_item_object', 'custom'),
(234, 72, '_menu_item_target', ''),
(235, 72, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(236, 72, '_menu_item_xfn', ''),
(237, 72, '_menu_item_url', '#'),
(239, 73, '_menu_item_type', 'custom'),
(240, 73, '_menu_item_menu_item_parent', '0'),
(241, 73, '_menu_item_object_id', '73'),
(242, 73, '_menu_item_object', 'custom'),
(243, 73, '_menu_item_target', ''),
(244, 73, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(245, 73, '_menu_item_xfn', ''),
(246, 73, '_menu_item_url', '#'),
(248, 74, '_menu_item_type', 'custom'),
(249, 74, '_menu_item_menu_item_parent', '0'),
(250, 74, '_menu_item_object_id', '74'),
(251, 74, '_menu_item_object', 'custom'),
(252, 74, '_menu_item_target', ''),
(253, 74, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(254, 74, '_menu_item_xfn', ''),
(255, 74, '_menu_item_url', '#'),
(257, 75, '_menu_item_type', 'custom'),
(258, 75, '_menu_item_menu_item_parent', '0'),
(259, 75, '_menu_item_object_id', '75'),
(260, 75, '_menu_item_object', 'custom'),
(261, 75, '_menu_item_target', ''),
(262, 75, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(263, 75, '_menu_item_xfn', ''),
(264, 75, '_menu_item_url', '#'),
(266, 76, '_menu_item_type', 'custom'),
(267, 76, '_menu_item_menu_item_parent', '0'),
(268, 76, '_menu_item_object_id', '76'),
(269, 76, '_menu_item_object', 'custom'),
(270, 76, '_menu_item_target', ''),
(271, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(272, 76, '_menu_item_xfn', ''),
(273, 76, '_menu_item_url', '#'),
(275, 77, '_menu_item_type', 'custom'),
(276, 77, '_menu_item_menu_item_parent', '0'),
(277, 77, '_menu_item_object_id', '77'),
(278, 77, '_menu_item_object', 'custom'),
(279, 77, '_menu_item_target', ''),
(280, 77, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(281, 77, '_menu_item_xfn', ''),
(282, 77, '_menu_item_url', '#'),
(284, 78, '_menu_item_type', 'custom'),
(285, 78, '_menu_item_menu_item_parent', '0'),
(286, 78, '_menu_item_object_id', '78'),
(287, 78, '_menu_item_object', 'custom'),
(288, 78, '_menu_item_target', ''),
(289, 78, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(290, 78, '_menu_item_xfn', ''),
(291, 78, '_menu_item_url', '#'),
(293, 79, '_menu_item_type', 'custom'),
(294, 79, '_menu_item_menu_item_parent', '0'),
(295, 79, '_menu_item_object_id', '79'),
(296, 79, '_menu_item_object', 'custom'),
(297, 79, '_menu_item_target', ''),
(298, 79, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(299, 79, '_menu_item_xfn', ''),
(300, 79, '_menu_item_url', '#');

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_posts`
--

CREATE TABLE `wpbasic_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_posts`
--

INSERT INTO `wpbasic_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-07-08 15:39:17', '2022-07-08 15:39:17', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2022-07-08 15:39:50', '2022-07-08 15:39:50', '', 0, 'http://localhost/wpbasic/?p=1', 0, 'post', '', 1),
(2, 1, '2022-07-08 15:39:17', '2022-07-08 15:39:17', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/wpbasic/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2022-07-08 15:39:56', '2022-07-08 15:39:56', '', 0, 'http://localhost/wpbasic/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-07-08 15:39:17', '2022-07-08 15:39:17', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/wpbasic.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2022-07-08 15:39:56', '2022-07-08 15:39:56', '', 0, 'http://localhost/wpbasic/?page_id=3', 0, 'page', '', 0),
(5, 1, '2022-07-08 15:39:50', '2022-07-08 15:39:50', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-07-08 15:39:50', '2022-07-08 15:39:50', '', 1, 'http://localhost/wpbasic/?p=5', 0, 'revision', '', 0),
(6, 1, '2022-07-08 15:39:56', '2022-07-08 15:39:56', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/wpbasic.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2022-07-08 15:39:56', '2022-07-08 15:39:56', '', 3, 'http://localhost/wpbasic/?p=6', 0, 'revision', '', 0),
(7, 1, '2022-07-08 15:39:56', '2022-07-08 15:39:56', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/wpbasic/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-07-08 15:39:56', '2022-07-08 15:39:56', '', 2, 'http://localhost/wpbasic/?p=7', 0, 'revision', '', 0),
(9, 1, '2022-07-08 15:56:46', '2022-07-08 15:56:46', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-wpbasic', '', '', '2022-07-08 15:56:46', '2022-07-08 15:56:46', '', 0, 'http://localhost/wpbasic/wp-global-styles-wpbasic/', 0, 'wp_global_styles', '', 0),
(12, 1, '2022-07-08 17:04:12', '2022-07-08 17:04:12', '', '1558ea75-72f7-3e32-9023-33d3f767423b', '', 'inherit', 'open', 'closed', '', '1558ea75-72f7-3e32-9023-33d3f767423b', '', '', '2022-07-08 17:04:12', '2022-07-08 17:04:12', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/1558ea75-72f7-3e32-9023-33d3f767423b.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2022-07-08 08:51:22', '2022-07-08 08:51:22', '<h2>Delectus et illum aut. Molestiae facere quos velit alias et. Perspiciatis in molestias consectetur nulla occaecati nemo</h2>\n<ul><li>Qui quia iure totam qui dolorem repudiandae</li><li>Nostrum cumque aspernatur placeat velit quo</li><li>Voluptates hic</li><li>Neque quasi consequuntur dolorum ut</li></ul>\n<blockquote><a title=\"Et aliquam.\" href=\"http://www.considine.info/\">Vel minima delectus</a> <a title=\"Officia aut dolorem consequatur voluptas.\" href=\"https://wilderman.org/recusandae-sunt-et-sapiente-soluta-saepe-ratione.html\">ab. Accusantium et est</a> <a title=\"Blanditiis ab rem necessitatibus.\" href=\"https://www.jast.net/quia-blanditiis-corrupti-vitae-dolore-exercitationem-et-ea-incidunt\">Voluptate ut</a> <a title=\"Magni illo.\" href=\"http://sawayn.biz/aut-ut-dolorem-vitae-dignissimos-dicta-debitis-et\">voluptatem voluptatem fugiat sequi. Dignissimos consequatur rem sequi</a> <a title=\"Dolorem vel illum ut aut eum et et.\" href=\"http://www.runte.com/\">non eos perferendis quam. Cupiditate</a> ducimus voluptatibus aut cupiditate velit nobis. esse sit officia veniam. Deserunt voluptates soluta quam cum</blockquote>\n<h2>Facilis beatae debitis non magni. Velit nemo omnis voluptas animi</h2>\n<blockquote>Minus omnis voluptas corrupti ullam corrupti et. Atque totam sit eum quasi tempore dolorum. Quae et culpa officia culpa.</blockquote>\n<img alt=\"Soluta qui eos error voluptas aut alias\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/1558ea75-72f7-3e32-9023-33d3f767423b.jpg\">', 'Ea aut nam nihil eveniet', 'Maxime.\n\nQui aut.', 'publish', 'open', 'open', '', 'ea-aut-nam-nihil-eveniet', '', '', '2022-07-08 08:51:22', '2022-07-08 08:51:22', '', 0, 'http://localhost/wpbasic/ea-aut-nam-nihil-eveniet/', 0, 'post', '', 0),
(14, 1, '2022-07-08 17:04:14', '2022-07-08 17:04:14', '', '2854de4e-e406-3a1c-8ac4-2b3dcb9b40b3', '', 'inherit', 'open', 'closed', '', '2854de4e-e406-3a1c-8ac4-2b3dcb9b40b3', '', '', '2022-07-08 17:04:14', '2022-07-08 17:04:14', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/2854de4e-e406-3a1c-8ac4-2b3dcb9b40b3.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2022-07-08 17:04:15', '2022-07-08 17:04:15', '', '4884eeba-1ef4-3f06-bbd1-58ab7b59a956', '', 'inherit', 'open', 'closed', '', '4884eeba-1ef4-3f06-bbd1-58ab7b59a956', '', '', '2022-07-08 17:04:15', '2022-07-08 17:04:15', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2022-07-08 10:26:46', '2022-07-08 10:26:46', '<h4>Nam hic aut consequatur deserunt. Vel dolores blanditiis minus eveniet itaque. Et quod est itaque</h4>\n<img alt=\"Omnis eligendi magni eveniet quod dolorem sunt ipsam\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n\n<hr>\n\n<ol>\n 	<li>Unde rem et ab quod et</li>\n 	<li>Sapiente minus qui</li>\n 	<li>Qui enim maiores vitae optio aliquid</li>\n 	<li>Fuga ea minus laborum qui</li>\n 	<li>Occaecati</li>\n 	<li>Cum qui</li>\n 	<li>Ut vitae sunt quae</li>\n</ol>\n<!--more-->\n<h5>Magni sapiente et quae animi porro natus. Atque ad ea perspiciatis. Velit in qui voluptatem enim</h5>\n<img alt=\"Possimus molestiae amet eum eaque porro ut\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n<ul>\n 	<li>Quia suscipit eveniet voluptatibus</li>\n 	<li>Consequatur repellendus aut iusto omnis</li>\n 	<li>Consequatur est qui quam aut quas</li>\n</ul>', 'Aliquam at ut quae rerum', 'Sed vel consectetur autem.\n\nNemo id rerum.', 'publish', 'open', 'open', '', 'aliquam-at-ut-quae-rerum', '', '', '2022-07-19 16:55:38', '2022-07-19 16:55:38', '', 0, 'http://localhost/wpbasic/aliquam-at-ut-quae-rerum/', 0, 'post', '', 0),
(17, 1, '2022-07-08 17:04:17', '2022-07-08 17:04:17', '', '669f8e2a-f647-376b-b8a8-a71aebd3b912', '', 'inherit', 'open', 'closed', '', '669f8e2a-f647-376b-b8a8-a71aebd3b912', '', '', '2022-07-08 17:04:17', '2022-07-08 17:04:17', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/669f8e2a-f647-376b-b8a8-a71aebd3b912.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2022-07-08 20:27:31', '2022-07-08 20:27:31', '<h1>Culpa rerum sunt deleniti in qui rem. Consequuntur eum debitis et. Modi autem fugit quaerat ad placeat</h1>\n<ol>\n 	<li>Quasi praesentium</li>\n 	<li>Alias ipsa illo voluptatem</li>\n</ol>\n<h3>Ipsum vitae laborum libero quam. Eum voluptatum nemo asperiores et dicta libero eius aut. Quis fugit culpa saepe excepturi ad explicabo. Nesciunt quam dolor et ut at quia</h3>\n\n<hr>\n\n<h2>Officia doloremque aut deleniti inventore quia sit quia non</h2>\n\n<hr>', 'Soluta eligendi eligendi veniam consequuntur fugiat sint', 'Ut corporis odio.', 'publish', 'open', 'closed', '', 'soluta-eligendi-eligendi-veniam-consequuntur-fugiat-sint', '', '', '2022-07-09 16:07:32', '2022-07-09 16:07:32', '', 0, 'http://localhost/wpbasic/?p=18', 0, 'post', '', 0),
(19, 1, '2022-07-08 17:04:20', '2022-07-08 17:04:20', '', '6855cf5a-b58b-3497-9d1f-c044a296c438', '', 'inherit', 'open', 'closed', '', '6855cf5a-b58b-3497-9d1f-c044a296c438', '', '', '2022-07-08 17:04:20', '2022-07-08 17:04:20', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/6855cf5a-b58b-3497-9d1f-c044a296c438.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2022-07-07 06:46:19', '2022-07-07 06:46:19', '<h6>Consequuntur laudantium atque magni rerum</h6>\n<hr>\n<blockquote>Omnis distinctio quia ut amet quia. Et et aperiam et illo. eius eius fugit numquam. quaerat eligendi. Alias optio nihil Sit quis dolore rerum est voluptatem consectetur. Enim qui laborum est non eveniet. cumque voluptas qui consequuntur laboriosam. Ut quia minima. Architecto quo nisi id ad id. vel culpa eveniet sit molestias quas. Nihil laboriosam omnis. repudiandae ipsum dolorum itaque adipisci aliquid. Consectetur amet ut aperiam. Delectus corporis quis aut illum. Soluta maxime repellendus perferendis in Sunt earum officia accusamus praesentium deleniti. Officia omnis est. Quae accusamus blanditiis nemo <a title=\"Numquam at eius id qui.\" href=\"http://www.beatty.com/non-cumque-voluptas-alias-dolores-odio-quisquam\">Dolorem voluptatem</a> et earum Odit odio molestias. Et veritatis ducimus omnis sed veniam.</blockquote>\n<ol><li>Accusantium modi et sapiente facere</li><li>Eaque iure ipsum omnis nulla quos error</li><li>Aut magnam qui corrupti eum beatae dicta</li><li>Velit aut dolore dicta illo</li><li>Quaerat optio esse</li><li>Nihil aut nisi qui odio aliquid error</li></ol>\n<h6>Sint tenetur laborum eos quisquam consectetur. Officiis ducimus occaecati consequatur similique voluptatem. Omnis excepturi deleniti eius adipisci beatae accusamus inventore</h6>\n\n<blockquote>Fugiat qui et sapiente eum enim eos. Deleniti dicta nulla explicabo rem aut. Doloribus dolores sed ullam veritatis provident quis dolor. Est voluptates aut illum qui dolores consequatur. Ea corrupti quae eius consectetur quo id. Temporibus sed ut magni in deserunt non qui et.</blockquote>\n<!--more-->\n<h3>Et recusandae ut quia qui veritatis. Possimus quasi enim officia</h3>\n<ul><li>Blanditiis aut beatae et atque sint</li><li>Vel veritatis qui vel</li></ul>\n<h4>Cum non laborum eligendi iure doloremque enim. Ipsam neque dolore eum. Distinctio eum eos beatae eius qui. Vero eaque ea ducimus</h4>\n<ul><li>Non voluptatem et sint voluptas modi</li><li>Architecto accusamus enim ut id</li><li>Rerum et aut</li><li>Placeat amet alias quia</li><li>Iste illo dicta autem</li><li>Itaque iste et</li></ul>', 'Sit ut sit sunt est aliquid', '', 'publish', 'open', 'closed', '', 'sit-ut-sit-sunt-est-aliquid', '', '', '2022-07-07 06:46:19', '2022-07-07 06:46:19', '', 0, 'http://localhost/wpbasic/sit-ut-sit-sunt-est-aliquid/', 0, 'post', '', 0),
(21, 1, '2022-07-08 17:04:50', '2022-07-08 17:04:50', '', '7f54bf55-fbba-394a-8332-93b3a03199bd', '', 'inherit', 'open', 'closed', '', '7f54bf55-fbba-394a-8332-93b3a03199bd', '', '', '2022-07-08 17:04:50', '2022-07-08 17:04:50', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/7f54bf55-fbba-394a-8332-93b3a03199bd.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2022-07-07 05:39:32', '2022-07-07 05:39:32', '<h2>Quia tenetur dolores veniam fugit autem illo. Aut sint molestias tempora et</h2>\n<blockquote>Saepe dolor provident repellat ex voluptas necessitatibus eum. <a title=\"Ut alias voluptas architecto.\" href=\"http://www.huels.info/quos-eos-quod-ut-ipsa-non.html\"><a title=\"Nobis.\" href=\"http://www.senger.com/impedit-ut-incidunt-et-ipsa-atque\">sint temporibus similique qui in.</a></a> odit quam temporibus distinctio. Cum ad voluptatem cupiditate velit <a title=\"Non necessitatibus nam assumenda a.\" href=\"http://www.jast.com/quis-ratione-occaecati-dolorum-soluta-porro-quas\">quasi</a> <a title=\"Et similique nesciunt illo quia recusandae nulla autem magni.\" href=\"http://www.stark.org/qui-incidunt-qui-delectus-doloremque-quo\">Et in qui</a> cumque <a title=\"Aut iste ea a tenetur ab ea quis at.\" href=\"http://rutherford.com/dolorem-enim-omnis-aut-quia-labore-saepe-possimus-a\">qui.</a> <a title=\"Sit voluptatem.\" href=\"http://zieme.com/rerum-similique-omnis-rerum-atque-vel-sit\">animi at ut</a> ipsam.</blockquote>\n<h1>Consequuntur fugiat et laborum et amet odit id. Voluptate assumenda perferendis et</h1>\n<ul><li>Maxime ipsam qui</li><li>Eos et unde maxime eius</li><li>Praesentium</li><li>Reiciendis excepturi</li><li>Consequatur suscipit id eum ut</li></ul>\n<p>Cum neque laboriosam rerum quod quis ullam aut aut. Qui explicabo magni corporis sint odit. Dignissimos qui et sit voluptatem enim. Suscipit cupiditate autem dolores dolor et eos. Animi temporibus culpa nobis quo a sed veniam. Nesciunt voluptas in aliquam facere aut nesciunt iure. Blanditiis et quae et quam excepturi. Laborum aut at deleniti laudantium culpa. Voluptatem voluptas et debitis et blanditiis et error. Sapiente ex voluptate est omnis labore explicabo. Atque eaque nihil hic excepturi ipsa eligendi. Repellat ipsa est alias laboriosam itaque harum ea. Quia tempore eum beatae ut nihil. Dolore reiciendis velit quia non. Nemo incidunt fugiat atque temporibus sit. Ullam sunt fugit odit tenetur esse. Enim consectetur voluptatem dolorem pariatur et ab impedit. Ad exercitationem delectus quis rem vel est. Soluta quidem nobis omnis ut voluptas. Laboriosam alias non amet natus quisquam similique pariatur. Eos est recusandae tenetur et id voluptatem. Blanditiis vero et perferendis quidem aspernatur consequatur explicabo. Quisquam velit modi qui amet.</p>\n<h2>Tenetur rerum quia tempora ut illo. Officiis omnis saepe placeat omnis perspiciatis dolorem ipsa tenetur. Autem itaque libero quis a sit impedit</h2>\n<!--more-->\n<ol><li>Error dolores sunt autem optio</li><li>Ipsa adipisci optio ut fugit qui</li><li>Asperiores numquam</li><li>Cum iste sit nulla voluptas autem ut reiciendis</li><li>Exercitationem in adipisci odit</li><li>Atque laboriosam odio ipsam maxime</li></ol>\n<p>Distinctio dolor quia amet porro aspernatur fugit recusandae voluptas. Quidem aspernatur dignissimos qui nesciunt quasi atque eaque qui. Nobis aspernatur aut ex aut. Amet veritatis mollitia voluptates aliquid. Fuga animi fugit impedit aspernatur est eveniet molestiae aut. Dolorem consectetur eum dolores aut voluptatibus et. Repudiandae et molestiae sint autem facilis soluta numquam. Odit est sed est dolorem. In voluptas quidem fugit vel. Quia aliquid est minus est maxime. Ea doloribus dolore vero doloribus et. Ut ratione commodi excepturi est.</p>\n<ul><li>Id velit dolorem omnis ut doloremque ut sit ea</li><li>Impedit libero et et omnis qui est ipsam ea</li><li>Officia</li><li>Sequi sed repellendus rem magnam eaque</li><li>Numquam dolorem</li><li>Ipsam minus quidem aliquam est</li><li>Et doloremque vitae harum aut fugit</li></ul>', 'Explicabo est debitis dolor molestiae', '', 'publish', 'open', 'open', '', 'explicabo-est-debitis-dolor-molestiae', '', '', '2022-07-07 05:39:32', '2022-07-07 05:39:32', '', 0, 'http://localhost/wpbasic/explicabo-est-debitis-dolor-molestiae/', 0, 'post', '', 0),
(23, 1, '2022-07-07 10:26:08', '2022-07-07 10:26:08', '<blockquote><a title=\"Magnam ipsa fuga beatae maxime placeat.\" href=\"http://www.metz.net/eius-earum-voluptatem-aut-voluptatum-eligendi\">Esse aliquid</a> dignissimos aliquid et. Deleniti minus corporis. Sed ratione <a title=\"Sint est est aut.\" href=\"https://pacocha.com/recusandae-id-hic-vel-et-sit.html\"><a title=\"Nulla.\" href=\"http://www.ebert.com/soluta-molestiae-occaecati-et-natus-consequatur\">possimus. Odio magni</a></a> rem et animi dicta. Eveniet alias sunt saepe maiores perspiciatis sit. Vel molestiae inventore fugiat. Autem <a title=\"Accusamus et quas nostrum eveniet iste.\" href=\"http://www.mueller.com/\"><a title=\"Consequatur minus quis nemo.\" href=\"http://sawayn.com/in-tempora-voluptas-molestiae-nemo-culpa-sed.html\">laborum aut</a></a> Aut <a title=\"Tenetur illo.\" href=\"http://klein.com/\">quis doloribus</a> rerum consequuntur. Quisquam rerum aut <a title=\"Iure dolore reiciendis eum accusantium reiciendis ratione tempore.\" href=\"http://ziemann.com/\">nostrum debitis dicta. Illum accusantium at</a> inventore Quia commodi sunt et reprehenderit consequuntur voluptatem distinctio. <a title=\"Et rerum vel quaerat quidem accusamus debitis et laborum sapiente.\" href=\"https://dicki.net/exercitationem-voluptate-rerum-voluptates.html\">totam fuga quo nobis. Nulla</a> <a title=\"Sunt quo assumenda qui commodi.\" href=\"http://www.block.com/\">velit voluptatibus et. Et expedita et</a> Recusandae perspiciatis autem sit ducimus.</blockquote>\n<h2>Nesciunt quas architecto quasi minus</h2>\n<ol><li>Voluptatem veniam eum vel consequatur tempore</li><li>Voluptas minus qui eveniet</li><li>Qui aut sint ducimus veritatis velit ullam</li><li>Nam accusamus quis</li><li>Autem et aut fugiat natus ut ratione ex</li></ol>\n<h5>Optio rerum exercitationem ducimus rem et quibusdam dolorem</h5>\n<ol><li>Maxime</li><li>Delectus animi sed sed rerum fuga tempore</li><li>Aut velit et consequuntur iste</li><li>Consequatur</li></ol>\n<h2>Similique aut alias ab. Explicabo ipsa minima assumenda qui saepe maiores. Ut dolore et itaque ut et sit</h2>\n<!--more-->\n<hr>\n<h3>Quod enim voluptas ullam modi amet nam. Ad sint laboriosam vel aut. Beatae error recusandae perferendis accusamus. Laborum molestiae et non quia laborum sit</h3>\n<ol><li>Voluptatum quo autem quo</li><li>Quae dicta iusto esse numquam</li><li>Sunt corrupti nisi eaque</li><li>Rem architecto aut sapiente mollitia</li></ol>\n\n<h5>Facilis qui voluptatem officiis et consequuntur dolor</h5>\n<blockquote>Magnam voluptatem eos ab enim aut. Vel et sint eaque earum qui. Impedit sapiente iste porro. Nobis sed nam beatae et Voluptatibus dicta ut dolorem natus placeat Corrupti laboriosam minima saepe beatae Dicta fuga est sed sit assumenda Quo eveniet aut unde. Consequatur aliquam sed aut. et nihil eveniet minima. Ab sed rerum. quia omnis aut aut rerum perferendis et. Illum officia nostrum et aut qui. et recusandae ipsa possimus quia quis animi. Atque odit dolor consequatur aut. doloribus voluptas saepe quae. unde quis nisi debitis in Aut earum repellendus sit sed dolores totam ut. Aut aut consequuntur corporis nemo laborum debitis. esse et unde quidem rerum ut. Ipsam aut non <a title=\"Corporis voluptatem impedit.\" href=\"http://www.mccullough.biz/\">alias. Ut</a> voluptatem aperiam voluptas. Voluptate placeat voluptas dolor natus et repellendus. corrupti occaecati Modi quidem mollitia excepturi recusandae. At non sint et Quo cumque ex nihil maxime quae exercitationem. Id et voluptas odio odio molestiae soluta. et minus ratione Eos laudantium ea ut sed Ut assumenda nisi eum. Harum et accusantium sit id nisi. Et minima laudantium aut. Nobis eos dolor deleniti distinctio voluptas. Est et molestiae quis quod molestias. molestiae rerum ea et occaecati et. Aut hic quia. In qui reprehenderit mollitia. Hic consequuntur itaque voluptates sed minima. Non nihil facilis ipsam deleniti vel. Quod libero et quia eos.</blockquote>\n<h6>Magni est quis ab. In enim repellendus suscipit aut impedit iusto qui. Velit omnis ipsa vel magni ut. Voluptas nobis qui in animi</h6>\n<p>Accusantium enim at distinctio Nihil doloremque ea libero. Eius assumenda consectetur nihil Recusandae aut consectetur eum. Sit ipsam ut culpa. modi et eaque. Id qui tempora inventore itaque dolor sunt qui. Modi voluptas Praesentium cupiditate natus nulla <a title=\"Pariatur.\" href=\"http://www.sipes.com/optio-at-fuga-totam-voluptas-atque-optio-cupiditate\">dolorem</a> Culpa voluptate consectetur Non ex <a title=\"Quia nihil consequatur est.\" href=\"https://white.com/corporis-dicta-cupiditate-autem-quod.html\">aut provident magni. Enim excepturi minima officia qui rem</a> Tempora aut adipisci eos tempore quia. sapiente et architecto magnam aperiam. Magni provident debitis quo recusandae.</p>\n<p><a title=\"Rerum aspernatur ut quam.\" href=\"https://www.kub.com/ut-itaque-dignissimos-dolores-omnis-quaerat\">Omnis nam est voluptates.</a> eveniet explicabo sed id. Dolores et itaque optio cum vel. Id reprehenderit sunt unde. rerum eum omnis possimus veritatis Doloremque nisi explicabo unde aspernatur cupiditate aliquam. Soluta iste est nam. Alias porro est nobis sed labore. Est nostrum cumque dolor quia aut et. Quis aperiam cum earum temporibus. Dolorem aut rerum reprehenderit ut porro. <a title=\"Et esse aut architecto error.\" href=\"http://herman.com/\">laborum qui cum</a> dolorem reprehenderit. Ab eligendi non beatae et voluptatum</p>', 'Id iure quam adipisci expedita suscipit maxime', 'Doloremque consequuntur autem.', 'publish', 'open', 'closed', '', 'id-iure-quam-adipisci-expedita-suscipit-maxime', '', '', '2022-07-07 10:26:08', '2022-07-07 10:26:08', '', 0, 'http://localhost/wpbasic/id-iure-quam-adipisci-expedita-suscipit-maxime/', 0, 'post', '', 0),
(24, 1, '2022-07-08 17:04:52', '2022-07-08 17:04:52', '', '61158792-202b-3d70-8396-6d6808125a2d', '', 'inherit', 'open', 'closed', '', '61158792-202b-3d70-8396-6d6808125a2d', '', '', '2022-07-08 17:04:52', '2022-07-08 17:04:52', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/61158792-202b-3d70-8396-6d6808125a2d.jpg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2022-07-07 12:14:50', '2022-07-07 12:14:50', '<blockquote><a title=\"Libero doloribus voluptatibus ipsam et neque.\" href=\"http://wilderman.com/culpa-adipisci-debitis-blanditiis-quasi-ipsam-tenetur-voluptatem\">Et ut incidunt</a> consequatur mollitia dignissimos. Repellendus <a title=\"Similique commodi deserunt in rerum perferendis.\" href=\"https://stehr.net/eos-nulla-voluptates-repellendus.html\">architecto eveniet sed</a> architecto. Illo voluptates vel Corrupti dolorem aut sunt non maiores cumque <a title=\"Explicabo maxime similique.\" href=\"http://www.koss.com/doloremque-et-vel-quo-voluptatem\">Aut sit dolorem</a> quas <a title=\"Sed.\" href=\"http://white.com/est-quia-aut-ducimus-eum-quia-dolorem-in-magnam.html\">dolor. Velit ipsum quam</a> <a title=\"Et.\" href=\"http://gaylord.com/accusantium-repellendus-beatae-quasi-ut.html\">iure sed occaecati. Quo</a> facere natus dolorum sint. Repellendus tempore</blockquote>\n<ul><li>Labore et nostrum ut quos qui aut</li><li>Eos occaecati</li><li>Facilis quo</li><li>Corrupti iusto et</li></ul>\n<h2>Quaerat sit autem necessitatibus molestias eligendi rerum dolor. Maiores sit rerum occaecati et temporibus voluptatibus. Amet fugiat ut velit tempora laboriosam et</h2>\n<!--more-->\n<ul><li>Odit rerum voluptatum ipsa</li><li>Quia provident nesciunt autem natus</li></ul>\n<hr>\n<h1>Magni ut blanditiis iste voluptatem eos sed. Neque atque voluptas magnam nulla</h1>\n<ol><li>Natus minus ipsum</li><li>Eligendi et porro doloremque</li><li>Autem vero aut</li><li>Id in quis magnam nobis</li></ol>\n<hr>\n<h2>Qui dolores ut esse unde occaecati et. Modi nihil commodi sit earum. Facere rerum dolor velit fuga</h2>\n<ul><li>Consequatur nemo incidunt nostrum expedita sed sit</li><li>Placeat quia officiis tempore quas</li><li>Molestiae ea omnis</li><li>Qui natus culpa dolorem</li><li>Sint facilis aut cupiditate</li><li>Nostrum</li></ul>\n<hr>\n<ul><li>Et autem distinctio hic</li><li>Assumenda sint ipsum vel voluptas</li><li>Officiis non voluptates est</li><li>Voluptas eos aut vel et</li><li>Mollitia est</li><li>Rerum sit dolor repellat</li><li>Provident ut est ut corporis</li><li>Dolore quos neque</li><li>Est quod qui id quis sunt</li></ul>', 'Dolorem doloremque quos mollitia modi impedit', '', 'publish', 'open', 'closed', '', 'dolorem-doloremque-quos-mollitia-modi-impedit', '', '', '2022-07-07 12:14:50', '2022-07-07 12:14:50', '', 0, 'http://localhost/wpbasic/dolorem-doloremque-quos-mollitia-modi-impedit/', 0, 'post', '', 0),
(26, 1, '2022-07-08 17:04:56', '2022-07-08 17:04:56', '', '9a7d3578-5dba-39a1-967b-ebd11460db0d', '', 'inherit', 'open', 'closed', '', '9a7d3578-5dba-39a1-967b-ebd11460db0d', '', '', '2022-07-08 17:04:56', '2022-07-08 17:04:56', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/9a7d3578-5dba-39a1-967b-ebd11460db0d.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2022-07-07 21:30:28', '2022-07-07 21:30:28', '<ol><li>Iusto eligendi enim sint pariatur vero</li><li>Odit nostrum</li><li>Aut aut culpa</li><li>Repellat quis quae et enim</li><li>Sit aut sit qui voluptates ad vitae</li><li>Rerum est sint vitae</li><li>Officia consectetur itaque laudantium aspernatur delectus</li><li>Et quae fugiat aspernatur</li></ol>\n<p><a title=\"Quo aperiam vitae officiis incidunt quod.\" href=\"http://www.lindgren.biz/molestiae-quaerat-aliquam-nesciunt-rem\">Tempore sed pariatur</a> Rem omnis iusto repellat Soluta fuga dolorem voluptatem quasi itaque laudantium. perferendis ullam sint et nam. commodi eius magnam autem voluptas illo Autem officia nihil et dolor et. Quas tempore occaecati voluptatem earum. Autem non et. Est aut facere. Nemo hic ut aut. Mollitia dolores accusantium A nobis quia dolorem mollitia sit. aliquid consequatur occaecati est impedit nobis. Sit corporis iusto in molestiae saepe. Tenetur <a title=\"Corporis est voluptas expedita.\" href=\"https://schumm.com/praesentium-reiciendis-velit-vero-a-quos-cumque.html\">ipsam aut et consequatur veniam. Non qui sint</a> doloremque minima. Voluptatem modi maiores veniam. Repudiandae vitae dolores. Molestiae vero dignissimos et maiores ipsum ratione</p>\n<!--more-->\n<h4>Quo aliquid non velit neque ab. Laborum recusandae quia sed rem quia. Dolore nobis soluta officia nulla id</h4>\n<blockquote>Cumque numquam autem quibusdam officiis non Odit voluptatum <a title=\"Ratione.\" href=\"http://littel.com/qui-quis-pariatur-autem.html\">eum dolores sed</a> optio. Doloremque suscipit est quidem Distinctio neque tempore id culpa ea. Qui est distinctio magnam voluptatum natus. perferendis placeat est consequatur in autem. Veniam <a title=\"Et non minus iure in.\" href=\"http://torphy.biz/\">facere dolore voluptas</a> ipsum Et recusandae totam ipsum occaecati quisquam itaque. Dolores et quia optio. Itaque omnis consequatur labore quo quod deserunt. Qui <a title=\"Dolores eveniet voluptatibus sunt praesentium quam.\" href=\"http://www.nikolaus.com/\">sed</a> modi.</blockquote>\n<blockquote>Adipisci qui neque quasi Nostrum <a title=\"Occaecati modi.\" href=\"http://www.friesen.com/est-voluptas-eligendi-minima-odit-nisi-dolores-quam\">voluptas numquam</a> neque. Impedit commodi neque consequuntur Sit quisquam eum Iusto suscipit aut provident eaque veritatis. Laboriosam dolore qui facilis minima. Aliquam facilis sint et Dolorum molestiae magni amet non et. Reprehenderit illo et consequuntur odit. Nihil voluptatem error eligendi Sint reprehenderit quibusdam qui <a title=\"Eveniet nisi dolorum deleniti.\" href=\"http://oconner.info/porro-recusandae-sit-animi-odit-assumenda-et\">perferendis et voluptatum cum.</a> <a title=\"Facere et.\" href=\"http://www.ferry.com/dolor-id-et-deleniti-vero-commodi-voluptates-rerum-alias\">commodi facere ut.</a> aspernatur et eligendi et cupiditate. Consequatur eos possimus ducimus pariatur ducimus voluptatem. Reiciendis vero dignissimos commodi. Non perferendis perspiciatis laborum quo. Quia et deserunt aut. Quibusdam corrupti quas qui excepturi Voluptas ad et minus ut. Necessitatibus assumenda sit. Facere nihil qui nam nisi vel. Aut autem nemo perferendis. <a title=\"Qui corporis est nisi exercitationem repudiandae recusandae consequuntur mollitia laborum id.\" href=\"https://eichmann.com/esse-vel-aliquid-dolorem-mollitia-vel-blanditiis-reiciendis.html\">rerum libero</a> maiores deleniti. dignissimos esse rerum. <a title=\"Nobis est veritatis modi aperiam est nihil.\" href=\"http://conn.info/\">voluptatem est</a> assumenda et non Sapiente neque nihil est. Rerum id occaecati optio veniam id. Voluptates veritatis ipsum nisi necessitatibus. Maxime itaque dignissimos numquam quod porro. Et sint eos cupiditate sint <a title=\"Eos voluptatem soluta molestiae quia repudiandae.\" href=\"http://toy.com/quae-placeat-commodi-quos-aut-est-dolor-officiis.html\">Rem rerum expedita temporibus quisquam repudiandae</a> qui. Rem sit et nisi esse sed corporis. Aperiam culpa delectus aut aspernatur cupiditate Ipsam illo dicta nihil et totam. Autem voluptate vitae eos fuga dignissimos. Dicta quia consequatur. Quam et alias rerum inventore. Laudantium vel labore sit.</blockquote>\n<p>Nisi quo <a title=\"Iure magni nulla autem.\" href=\"http://berge.com/exercitationem-eius-similique-est-praesentium-consectetur-magni.html\">a</a> <a title=\"Voluptate laboriosam.\" href=\"https://www.von.com/porro-nulla-tempore-rem\">aut iste. Molestias delectus</a> blanditiis. Officia doloremque itaque laborum accusamus <a title=\"Fugiat pariatur temporibus quos.\" href=\"https://www.greenholt.com/sit-sit-quis-officia-quae-iusto-facilis\">repellendus. Qui</a> quaerat neque Consequatur unde et corporis deleniti. Quas sequi earum qui rerum maxime. Et nostrum nihil velit expedita.</p>\n<h1>Laborum rerum ea quae in est ducimus repellat. Deleniti et consequatur reprehenderit occaecati. Commodi et et tenetur aut illo non non</h1>\n<ul><li>Vitae rerum ratione dolores</li><li>Debitis voluptas odit sit ut</li><li>Impedit et qui ut error</li><li>Inventore dolor et et vitae</li><li>Qui quo est</li></ul>\n<hr>', 'Similique voluptatem voluptate nihil', '', 'publish', 'open', 'open', '', 'similique-voluptatem-voluptate-nihil', '', '', '2022-07-07 21:30:28', '2022-07-07 21:30:28', '', 0, 'http://localhost/wpbasic/similique-voluptatem-voluptate-nihil/', 0, 'post', '', 0),
(28, 1, '2022-07-08 17:04:57', '2022-07-08 17:04:57', '', 'e6e429ee-b6b2-3ee3-8863-74643f1b73a4', '', 'inherit', 'open', 'closed', '', 'e6e429ee-b6b2-3ee3-8863-74643f1b73a4', '', '', '2022-07-08 17:04:57', '2022-07-08 17:04:57', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/e6e429ee-b6b2-3ee3-8863-74643f1b73a4.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2022-07-08 17:04:59', '2022-07-08 17:04:59', '', '6e8dec3c-79a4-3b94-98cb-d228337dc848', '', 'inherit', 'open', 'closed', '', '6e8dec3c-79a4-3b94-98cb-d228337dc848', '', '', '2022-07-08 17:04:59', '2022-07-08 17:04:59', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2022-07-07 10:06:06', '2022-07-07 10:06:06', '<ol><li>Illum modi id est ipsa</li><li>Ad ex iure vel sed</li><li>Accusantium</li><li>Molestias quo ex consequuntur</li></ol>\n<h4>Maiores error nam et eum magni molestiae. Blanditiis non sint et inventore. Vel corrupti reprehenderit eum. Sint necessitatibus iure ea qui</h4>\n<!--more-->\n<img class=\"alignleft\" alt=\"Autem qui impedit reprehenderit est ad\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg\">\n<hr>\n<h6>Alias aut et rerum enim laborum eaque nostrum odit. Eligendi deserunt velit occaecati velit eius eum reprehenderit. Porro vero possimus assumenda</h6>\n<p>Quo iste non. Molestiae vero libero voluptatem excepturi et. Non totam neque. necessitatibus id velit aut at. Ad maxime nobis quisquam eum. ut nemo est inventore ad. Dolor qui inventore velit. Est est consequuntur cumque. Enim aut at minus nobis qui magni. Reprehenderit dolor nostrum repellat velit. Illo rem eum quas veniam autem. Commodi laborum quo reiciendis Temporibus voluptatum mollitia expedita sed id. deserunt sed voluptatem magnam voluptas Suscipit unde corporis exercitationem non excepturi. sit amet dolor ad. Facere dicta natus temporibus dolorum. quo molestiae aut sint. Vero doloribus repellendus nulla <a title=\"Voluptatem voluptas voluptatibus et delectus asperiores rerum deserunt molestiae modi veritatis molestias.\" href=\"http://www.erdman.com/quidem-odit-temporibus-quia-minima-fugiat\">dolore</a> Explicabo architecto nobis tenetur necessitatibus dolorum Iure accusantium sed Tempora quidem facere ipsa aut. et fuga eius sit rem dolorem. architecto dolores accusantium Totam repudiandae est. Rerum id magnam at aspernatur. Maxime eum est corporis distinctio sapiente veniam. Odit voluptas atque. Atque qui alias doloremque fugiat quia. Et sed ipsa vel cupiditate vitae et Quidem quis aperiam tempora quaerat. Dicta est qui placeat quo. tempora nam culpa ipsam voluptate. Ad ratione <a title=\"Omnis rem consequuntur quis.\" href=\"http://schumm.com/quasi-consequuntur-voluptatum-quis-sint-est.html\">eum occaecati facilis dolore. Rerum</a> alias qui inventore. Facere quidem et eligendi assumenda. eos perferendis rerum amet veniam. Optio qui incidunt omnis ratione. Ipsa dolorem repellendus id. Aliquam et minus repellendus enim et Modi sunt fugit explicabo ea dignissimos.</p>', 'Eos molestias et velit at aliquid voluptatem quis', 'Qui et aliquid.\n\nOdit cupiditate voluptatem.\n\nError ipsam.\n\nVoluptatibus quia.', 'publish', 'open', 'open', '', 'eos-molestias-et-velit-at-aliquid-voluptatem-quis', '', '', '2022-07-07 10:06:06', '2022-07-07 10:06:06', '', 0, 'http://localhost/wpbasic/eos-molestias-et-velit-at-aliquid-voluptatem-quis/', 0, 'post', '', 0),
(31, 1, '2022-07-08 17:05:01', '2022-07-08 17:05:01', '', '6828e009-6770-3891-8af8-7da3ffafba51', '', 'inherit', 'open', 'closed', '', '6828e009-6770-3891-8af8-7da3ffafba51', '', '', '2022-07-08 17:05:01', '2022-07-08 17:05:01', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/6828e009-6770-3891-8af8-7da3ffafba51.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2022-07-07 19:40:35', '2022-07-07 19:40:35', '<h5>Saepe deleniti cum harum reiciendis</h5>\n\n<hr>\n\n<!--more-->\n<h2>Autem occaecati quo magnam ducimus quae voluptas id. Fugit dolorem veniam error sit quia ullam distinctio numquam. Qui aut quos est eum dolores hic nihil</h2>\n<ul>\n 	<li>Sequi fugiat et sed aut</li>\n 	<li>Et voluptas quasi alias porro ipsam</li>\n 	<li>Sint autem velit omnis</li>\n 	<li>Quam et nostrum</li>\n 	<li>Quis repellat</li>\n</ul>\n<ol>\n 	<li>Hic temporibus aut atque soluta pariatur</li>\n 	<li>Deserunt et at magni in</li>\n 	<li>At facilis soluta unde</li>\n 	<li>Enim aliquam qui ipsum</li>\n</ol>', 'Commodi maiores ut voluptatibus incidunt', 'Quis.', 'publish', 'open', 'open', '', 'commodi-maiores-ut-voluptatibus-incidunt', '', '', '2022-07-08 17:19:13', '2022-07-08 17:19:13', '', 0, 'http://localhost/wpbasic/commodi-maiores-ut-voluptatibus-incidunt/', 0, 'post', '', 0),
(33, 1, '2022-07-08 17:05:05', '2022-07-08 17:05:05', '', '542cb711-4284-3292-8a3c-e2e605c70a99', '', 'inherit', 'open', 'closed', '', '542cb711-4284-3292-8a3c-e2e605c70a99', '', '', '2022-07-08 17:05:05', '2022-07-08 17:05:05', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/542cb711-4284-3292-8a3c-e2e605c70a99.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `wpbasic_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(34, 1, '2022-07-07 18:19:02', '2022-07-07 18:19:02', '<h6>Alias fuga nisi ipsam. Dolorem at odit deserunt omnis. Voluptas consequuntur deleniti quos quos omnis</h6>\n<img alt=\"Autem esse\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/542cb711-4284-3292-8a3c-e2e605c70a99.jpg\">\n<h1>Exercitationem sint nam occaecati. Voluptatem id in quia qui voluptatem ab. Soluta quam sapiente magni a blanditiis facilis. Perferendis nihil eligendi ea quos eum maiores ut</h1>\n<!--more-->\n<ol>\n 	<li>Eveniet atque aut ipsam cumque ab</li>\n 	<li>Dolore quisquam non</li>\n 	<li>Enim maxime non eaque nesciunt in est est</li>\n 	<li>Et perferendis animi molestias aut</li>\n 	<li>Sit rerum accusamus aut nisi esse nulla ducimus</li>\n</ol>\n<h6>Et fuga rerum ducimus voluptatem. Est earum aut et totam. Nam assumenda tempora voluptas maiores quidem nulla</h6>\nEt totam aut explicabo rerum repellat aut. Blanditiis a dignissimos ratione facilis voluptas. facilis officia perspiciatis dolor. Ipsam voluptas minima est voluptatem voluptatem. Quia quis dolor sit quia dolorem ullam. Explicabo qui dicta quam. repudiandae voluptatum repellat fugiat. Et ab <a title=\"Nihil enim.\" href=\"http://www.toy.com/et-est-dolor-et-autem.html\">suscipit</a> aliquam non. Nostrum sequi cupiditate commodi et. Facilis porro doloremque repellendus aut. a sunt rerum itaque vel Ut maxime est aspernatur consequatur Similique ut dolorum cumque possimus. Magnam quis vero nam qui id. Non ipsa eaque tempore. Ipsa voluptatem ullam Quis ea provident incidunt enim expedita. modi in temporibus autem beatae. et ipsa et Nihil quod perferendis quia dolores. asperiores et veritatis quo dolores. similique ut dolore autem eos. sit accusamus rerum. Et assumenda iusto hic. Fugiat laboriosam aliquid eveniet aut est. Non incidunt rerum laudantium. Esse suscipit cum qui id. non cupiditate iste. Mollitia dolores adipisci. Non quis laboriosam a cupiditate et veritatis. Illum ab aliquam dolorem\n<h2>Et consequatur ratione officia impedit</h2>\n<blockquote>Amet iusto <a title=\"Laudantium enim illum aut rerum.\" href=\"https://ryan.com/enim-qui-est-rerum-dicta-libero-aut-animi-quasi.html\">vel</a> sapiente quidem. Molestiae voluptatem ut fugit earum. Sequi ab quas ducimus omnis Qui quis rerum non. Recusandae dolores earum dolorum hic Ipsa aperiam voluptatem voluptatem Impedit reprehenderit dolor qui fuga nobis. Vitae exercitationem sint molestiae Possimus sapiente vel quia commodi. Natus natus aut ex iure placeat non qui. Pariatur repellendus ab enim dolorem. Consequatur <a title=\"Cumque facilis non.\" href=\"http://reinger.com/dolores-exercitationem-tempore-commodi-consectetur\">perspiciatis ipsa. Quam dignissimos</a> ea porro. Eius distinctio blanditiis optio facere. Neque quis ea cupiditate. Et incidunt fugiat et. Dolores iste rerum modi Soluta culpa asperiores autem velit nesciunt. Fugit sed ad dolorem eos <a title=\"Ullam sed.\" href=\"http://okon.com/dolor-ipsam-doloribus-ducimus-voluptas.html\">perspiciatis temporibus. Voluptates</a> blanditiis illum quo debitis aut ut. Quae odio atque qui maiores molestiae. Voluptatem et omnis eaque incidunt.</blockquote>', 'Eum quas neque expedita', '', 'publish', 'open', 'closed', '', 'eum-quas-neque-expedita', '', '', '2022-07-19 16:56:24', '2022-07-19 16:56:24', '', 0, 'http://localhost/wpbasic/eum-quas-neque-expedita/', 0, 'post', '', 0),
(35, 1, '2022-07-07 00:28:07', '2022-07-07 00:28:07', '<h2>Adipisci sit magnam dolorem odit pariatur et dolorem</h2>\n<ol><li>Quam modi non deserunt quo qui</li><li>Esse atque ex odit molestiae cum</li><li>Rerum voluptas</li><li>Id consequatur aliquid sunt</li><li>Autem aperiam</li></ol>\n<h2>Sit facilis qui veniam aut vel eius. Eos natus et laborum. Sequi expedita maiores dolores vero</h2>\n<p>Itaque provident nulla harum tenetur amet. accusantium autem ut quia. Quas nam consectetur ea Non aut quisquam nostrum ab minima enim. iusto accusamus atque velit expedita dicta. Non qui delectus beatae voluptates. unde commodi quos. Voluptate alias voluptas totam. Quae delectus sint labore asperiores Molestiae blanditiis laboriosam Esse ducimus quam ut quia. Aut ut qui omnis <a title=\"Debitis ea cupiditate alias.\" href=\"http://www.mante.net/totam-optio-quas-dolore-praesentium-eveniet\">Ut repellendus enim eveniet occaecati</a> Dolorem sit laudantium nemo laborum Ut dolor voluptatum laudantium iure ad porro quia. dolorum dolor. Blanditiis rerum assumenda eos id. Eos quam id voluptates at Velit maiores tempore amet non repellendus vero. Rerum doloribus qui dignissimos cumque laboriosam.</p>\n<h1>Dolorem maxime aliquid in et nesciunt. Tenetur quibusdam voluptas similique sint nisi. Dolores fuga repellendus quae impedit. Autem dignissimos asperiores nisi dolorum et aliquid</h1>\n<p>Eum voluptates aut aut quibusdam neque. Nulla voluptas recusandae dolor alias. Sed in unde quos dicta.</p>\n<ul><li>Tempora et quae a ut est</li><li>Dolorem consequatur dolore accusantium</li><li>Et nostrum quasi porro quis quasi</li><li>Alias fuga</li></ul>\n<h1>Voluptates suscipit deleniti repudiandae eum. Numquam saepe quia beatae blanditiis quibusdam. Cupiditate dolorum molestias pariatur mollitia itaque dolores corrupti. Enim dolor facilis aut</h1>\n<ul><li>Cupiditate autem blanditiis ut quibusdam voluptatibus</li><li>Laborum ea vel ex</li><li>Voluptatem ut dignissimos culpa</li><li>Nam sed nostrum vitae distinctio</li><li>Laudantium</li><li>Voluptas corporis quos aut</li><li>Ad nemo ut sequi ut et minima</li></ul>\n<h1>Expedita tempore molestiae hic illum porro omnis. Et soluta molestiae sequi. Eveniet quo excepturi distinctio nostrum itaque</h1>\n<blockquote>Non porro et et <a title=\"Et magni a qui nobis vitae dolores numquam voluptatem sunt laborum.\" href=\"https://www.haag.org/illo-dolorem-voluptatem-qui-assumenda-et-eos\">placeat.</a> eos <a title=\"Reiciendis sapiente ipsum quia autem vel.\" href=\"http://www.cormier.net/\">illum</a> occaecati. Ea nihil ullam exercitationem aut culpa. At magnam aut dolores omnis quia. Qui iusto qui porro tenetur voluptates similique</blockquote>\n<hr>', 'Omnis incidunt sapiente et autem qui modi', 'Sed soluta enim.\n\nQuos laboriosam non.', 'publish', 'open', 'closed', '', 'omnis-incidunt-sapiente-et-autem-qui-modi', '', '', '2022-07-19 16:56:35', '2022-07-19 16:56:35', '', 0, 'http://localhost/wpbasic/omnis-incidunt-sapiente-et-autem-qui-modi/', 0, 'post', '', 0),
(36, 1, '2022-07-08 17:05:08', '2022-07-08 17:05:08', '', '63334320-9931-340d-954e-284aa1f7bb55', '', 'inherit', 'open', 'closed', '', '63334320-9931-340d-954e-284aa1f7bb55', '', '', '2022-07-08 17:05:08', '2022-07-08 17:05:08', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/63334320-9931-340d-954e-284aa1f7bb55.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2022-07-07 23:14:57', '2022-07-07 23:14:57', '<blockquote>Quos nesciunt fuga quod Possimus quidem architecto <a title=\"Velit nisi sed labore et fugit.\" href=\"http://www.stehr.com/sit-quasi-ut-voluptate.html\">quidem provident aut.</a> quae aut possimus labore omnis unde. facere deserunt consequatur odio <a title=\"Et sit quaerat assumenda.\" href=\"https://www.smitham.com/omnis-expedita-recusandae-corporis\">sit aut. Ut ut</a> iure possimus. <a title=\"Dolorem.\" href=\"http://www.price.com/\">facilis eaque</a> voluptas in dolor. Quaerat est inventore quidem et voluptatem earum Minima enim velit voluptatem voluptatem. Rem et placeat excepturi exercitationem sunt. Consequatur voluptates <a title=\"Reprehenderit blanditiis dolorem.\" href=\"http://www.stamm.com/enim-corrupti-nesciunt-at-odio-quos-beatae-a-repudiandae\">aut. Voluptatum eos</a> assumenda quam quia. Qui repellat totam earum impedit ullam aut. ut officia <a title=\"Dolorem atque unde ea.\" href=\"http://robel.com/\">Tempora voluptatum</a> sequi esse est numquam. Ut qui necessitatibus voluptas. Expedita quisquam et vero atque quo. ipsa sunt <a title=\"Asperiores nostrum sed ad.\" href=\"http://dubuque.com/\">Ex nemo cupiditate magnam exercitationem blanditiis.</a> <a title=\"Non aliquam facilis excepturi.\" href=\"http://www.hansen.com/illo-beatae-delectus-delectus-possimus-voluptatem-totam.html\">sed magnam</a> accusantium. Recusandae quis sapiente veniam voluptatem. Dicta blanditiis odit dolores dolores laborum. Voluptatum voluptas nulla Consectetur exercitationem minus distinctio</blockquote>\n<h6>Non eos sed sed nemo</h6>\nQuas minus enim ut. Voluptate ipsam alias voluptate dolorem porro. omnis quas dolorum cumque. Sint dolores sit illo consequuntur Cupiditate sint ipsa qui et. Nostrum sunt numquam dolor nam. Culpa <a title=\"Assumenda.\" href=\"http://www.lang.com/ipsum-eius-adipisci-nostrum-minus-omnis\">nihil quo dolorem</a> quod sed officiis.\n<ul>\n 	<li>Voluptate porro</li>\n 	<li>Ut qui</li>\n 	<li>Tenetur eaque qui consequuntur eos</li>\n 	<li>Totam</li>\n 	<li>Adipisci et culpa molestias et dolores</li>\n 	<li>Perferendis quia ratione vel odit</li>\n</ul>\n<blockquote>Sunt dolor nobis tempore ab qui qui <a title=\"Ut eos.\" href=\"http://www.oreilly.com/eos-et-voluptatum-reprehenderit-modi-id\">Et quae molestiae</a> molestias. Hic porro dolorem consequatur mollitia quasi Et nemo et amet nostrum. Vero aut qui <a title=\"Neque et eum dolore.\" href=\"https://leuschke.com/adipisci-sequi-veniam-pariatur-eveniet-culpa-dolorum-officia.html\">voluptatem.</a></blockquote>\n<h2>Doloremque expedita facere dolor. Atque et aut praesentium qui aut. Tempore commodi doloremque ut. Aspernatur tenetur impedit consequatur et beatae</h2>\nMagni dolor sit voluptas quis dolores. Consectetur consequatur nobis numquam consequatur est. Laborum corporis adipisci eos corporis ducimus est. Est sint id quia aut atque. qui recusandae inventore voluptatum. Praesentium dolores quae ipsam harum voluptates. culpa cumque consequatur doloribus dicta omnis. Et aliquid et maxime porro. Animi delectus asperiores quaerat placeat rerum vitae. Est dignissimos laudantium provident nemo. Consequatur quo ipsum non accusantium. eius exercitationem sit in corrupti eum. Vel ipsa consectetur ad ipsum Asperiores quaerat ea aut in eos commodi ut. amet vitae incidunt voluptatem ut. Nostrum sint sed accusamus voluptatibus. Quam a quam reprehenderit quia. Voluptas quas aperiam velit. Quas aut debitis nostrum qui rem Recusandae occaecati magni aut omnis qui. Earum doloribus <a title=\"Reprehenderit voluptatem molestiae omnis.\" href=\"http://www.runolfsdottir.org/tempora-maiores-ea-alias-quo-autem\">aspernatur sunt minus quidem est. Eaque culpa ab deleniti</a> est veritatis. Aut vitae impedit ut occaecati officia et. Et qui quam consequuntur libero et corrupti.\n<h6>Et doloremque neque rem facere asperiores possimus. Ad temporibus sint sunt quo quasi labore</h6>\n<!--more-->\n\n<a title=\"Veritatis ad cupiditate qui.\" href=\"http://gerhold.org/deserunt-ab-assumenda-possimus-rem-ad-distinctio\">Corrupti perferendis et</a> provident voluptatem Dolores nihil sint rem. Officiis ab doloribus eaque. <a title=\"Commodi id.\" href=\"http://www.spencer.com/\">est cumque aut provident porro. Culpa</a> fugiat nobis <a title=\"Aut iusto et corrupti quo.\" href=\"http://schroeder.com/\">dolorem et ipsum.</a> voluptatem est tempore praesentium eveniet Debitis delectus optio qui ut. Voluptas ex a nisi quo iusto occaecati.\n<h2>Ea quibusdam nisi laboriosam. Fuga at sit omnis rerum recusandae. Quaerat dicta sint voluptatibus quos expedita eaque</h2>\n\n<hr>\n\n<blockquote>Reiciendis est fugiat ullam dolore omnis aut. In totam ipsam nam sit atque ea. Impedit quo et voluptatum quis possimus. Voluptatibus suscipit quia voluptas minus nihil. Libero nostrum vero modi nulla omnis aut repellat reiciendis. Laudantium enim quo deleniti et tenetur quam inventore. Consequuntur saepe iusto nostrum esse eum ea autem hic. Fugit rerum sint et veniam et.</blockquote>\n<h5>Libero recusandae dolorum possimus ut voluptatum enim amet. Ad et qui in a quas qui. Pariatur reiciendis illo placeat hic sed beatae possimus</h5>\nOdit mollitia id assumenda quos eum <a title=\"Consequatur fugit consectetur libero blanditiis.\" href=\"http://farrell.com/est-ut-adipisci-et-nemo-autem-earum-enim.html\">Qui veritatis</a> est <a title=\"Et quod aut omnis.\" href=\"http://www.stanton.com/doloremque-velit-quia-earum\">aliquam sint.</a> repudiandae illum ducimus Voluptas ullam qui architecto est Perferendis et ipsum natus. Reprehenderit <a title=\"Deserunt quae soluta error omnis dolore.\" href=\"http://www.haley.info/molestias-error-et-iste-aut-molestias-quis-est.html\">odit accusantium</a> <a title=\"Eveniet consequatur soluta.\" href=\"http://www.williamson.com/ut-inventore-illum-odio-non.html\">eveniet accusamus non. Incidunt</a> harum quos corrupti vel quas Cumque enim nam <a title=\"Accusantium nihil.\" href=\"http://www.goodwin.org/optio-necessitatibus-tempore-esse-delectus-et-voluptatem-minima\">aut voluptates. Necessitatibus</a> ad facilis laudantium aperiam. Voluptate aliquam et aut libero. Quis earum voluptas consectetur sed ut quidem.', 'Voluptas voluptatem consequatur velit voluptate', '', 'publish', 'open', 'open', '', 'voluptas-voluptatem-consequatur-velit-voluptate', '', '', '2022-07-19 16:55:56', '2022-07-19 16:55:56', '', 0, 'http://localhost/wpbasic/voluptas-voluptatem-consequatur-velit-voluptate/', 0, 'post', '', 0),
(38, 1, '2022-07-08 17:19:01', '2022-07-08 17:19:01', '<blockquote>Quos nesciunt fuga quod Possimus quidem architecto <a title=\"Velit nisi sed labore et fugit.\" href=\"http://www.stehr.com/sit-quasi-ut-voluptate.html\">quidem provident aut.</a> quae aut possimus labore omnis unde. facere deserunt consequatur odio <a title=\"Et sit quaerat assumenda.\" href=\"https://www.smitham.com/omnis-expedita-recusandae-corporis\">sit aut. Ut ut</a> iure possimus. <a title=\"Dolorem.\" href=\"http://www.price.com/\">facilis eaque</a> voluptas in dolor. Quaerat est inventore quidem et voluptatem earum Minima enim velit voluptatem voluptatem. Rem et placeat excepturi exercitationem sunt. Consequatur voluptates <a title=\"Reprehenderit blanditiis dolorem.\" href=\"http://www.stamm.com/enim-corrupti-nesciunt-at-odio-quos-beatae-a-repudiandae\">aut. Voluptatum eos</a> assumenda quam quia. Qui repellat totam earum impedit ullam aut. ut officia <a title=\"Dolorem atque unde ea.\" href=\"http://robel.com/\">Tempora voluptatum</a> sequi esse est numquam. Ut qui necessitatibus voluptas. Expedita quisquam et vero atque quo. ipsa sunt <a title=\"Asperiores nostrum sed ad.\" href=\"http://dubuque.com/\">Ex nemo cupiditate magnam exercitationem blanditiis.</a> <a title=\"Non aliquam facilis excepturi.\" href=\"http://www.hansen.com/illo-beatae-delectus-delectus-possimus-voluptatem-totam.html\">sed magnam</a> accusantium. Recusandae quis sapiente veniam voluptatem. Dicta blanditiis odit dolores dolores laborum. Voluptatum voluptas nulla Consectetur exercitationem minus distinctio</blockquote>\n<h6>Non eos sed sed nemo</h6>\nQuas minus enim ut. Voluptate ipsam alias voluptate dolorem porro. omnis quas dolorum cumque. Sint dolores sit illo consequuntur Cupiditate sint ipsa qui et. Nostrum sunt numquam dolor nam. Culpa <a title=\"Assumenda.\" href=\"http://www.lang.com/ipsum-eius-adipisci-nostrum-minus-omnis\">nihil quo dolorem</a> quod sed officiis.\n<ul>\n 	<li>Voluptate porro</li>\n 	<li>Ut qui</li>\n 	<li>Tenetur eaque qui consequuntur eos</li>\n 	<li>Totam</li>\n 	<li>Adipisci et culpa molestias et dolores</li>\n 	<li>Perferendis quia ratione vel odit</li>\n</ul>\n<blockquote>Sunt dolor nobis tempore ab qui qui <a title=\"Ut eos.\" href=\"http://www.oreilly.com/eos-et-voluptatum-reprehenderit-modi-id\">Et quae molestiae</a> molestias. Hic porro dolorem consequatur mollitia quasi Et nemo et amet nostrum. Vero aut qui <a title=\"Neque et eum dolore.\" href=\"https://leuschke.com/adipisci-sequi-veniam-pariatur-eveniet-culpa-dolorum-officia.html\">voluptatem.</a></blockquote>\n<h2>Doloremque expedita facere dolor. Atque et aut praesentium qui aut. Tempore commodi doloremque ut. Aspernatur tenetur impedit consequatur et beatae</h2>\nMagni dolor sit voluptas quis dolores. Consectetur consequatur nobis numquam consequatur est. Laborum corporis adipisci eos corporis ducimus est. Est sint id quia aut atque. qui recusandae inventore voluptatum. Praesentium dolores quae ipsam harum voluptates. culpa cumque consequatur doloribus dicta omnis. Et aliquid et maxime porro. Animi delectus asperiores quaerat placeat rerum vitae. Est dignissimos laudantium provident nemo. Consequatur quo ipsum non accusantium. eius exercitationem sit in corrupti eum. Vel ipsa consectetur ad ipsum Asperiores quaerat ea aut in eos commodi ut. amet vitae incidunt voluptatem ut. Nostrum sint sed accusamus voluptatibus. Quam a quam reprehenderit quia. Voluptas quas aperiam velit. Quas aut debitis nostrum qui rem Recusandae occaecati magni aut omnis qui. Earum doloribus <a title=\"Reprehenderit voluptatem molestiae omnis.\" href=\"http://www.runolfsdottir.org/tempora-maiores-ea-alias-quo-autem\">aspernatur sunt minus quidem est. Eaque culpa ab deleniti</a> est veritatis. Aut vitae impedit ut occaecati officia et. Et qui quam consequuntur libero et corrupti.\n<h6>Et doloremque neque rem facere asperiores possimus. Ad temporibus sint sunt quo quasi labore</h6>\n<!--more-->\n\n<a title=\"Veritatis ad cupiditate qui.\" href=\"http://gerhold.org/deserunt-ab-assumenda-possimus-rem-ad-distinctio\">Corrupti perferendis et</a> provident voluptatem Dolores nihil sint rem. Officiis ab doloribus eaque. <a title=\"Commodi id.\" href=\"http://www.spencer.com/\">est cumque aut provident porro. Culpa</a> fugiat nobis <a title=\"Aut iusto et corrupti quo.\" href=\"http://schroeder.com/\">dolorem et ipsum.</a> voluptatem est tempore praesentium eveniet Debitis delectus optio qui ut. Voluptas ex a nisi quo iusto occaecati.\n<h2>Ea quibusdam nisi laboriosam. Fuga at sit omnis rerum recusandae. Quaerat dicta sint voluptatibus quos expedita eaque</h2>\n\n<hr>\n\n<blockquote>Reiciendis est fugiat ullam dolore omnis aut. In totam ipsam nam sit atque ea. Impedit quo et voluptatum quis possimus. Voluptatibus suscipit quia voluptas minus nihil. Libero nostrum vero modi nulla omnis aut repellat reiciendis. Laudantium enim quo deleniti et tenetur quam inventore. Consequuntur saepe iusto nostrum esse eum ea autem hic. Fugit rerum sint et veniam et.</blockquote>\n<h5>Libero recusandae dolorum possimus ut voluptatum enim amet. Ad et qui in a quas qui. Pariatur reiciendis illo placeat hic sed beatae possimus</h5>\nOdit mollitia id assumenda quos eum <a title=\"Consequatur fugit consectetur libero blanditiis.\" href=\"http://farrell.com/est-ut-adipisci-et-nemo-autem-earum-enim.html\">Qui veritatis</a> est <a title=\"Et quod aut omnis.\" href=\"http://www.stanton.com/doloremque-velit-quia-earum\">aliquam sint.</a> repudiandae illum ducimus Voluptas ullam qui architecto est Perferendis et ipsum natus. Reprehenderit <a title=\"Deserunt quae soluta error omnis dolore.\" href=\"http://www.haley.info/molestias-error-et-iste-aut-molestias-quis-est.html\">odit accusantium</a> <a title=\"Eveniet consequatur soluta.\" href=\"http://www.williamson.com/ut-inventore-illum-odio-non.html\">eveniet accusamus non. Incidunt</a> harum quos corrupti vel quas Cumque enim nam <a title=\"Accusantium nihil.\" href=\"http://www.goodwin.org/optio-necessitatibus-tempore-esse-delectus-et-voluptatem-minima\">aut voluptates. Necessitatibus</a> ad facilis laudantium aperiam. Voluptate aliquam et aut libero. Quis earum voluptas consectetur sed ut quidem.', 'Voluptas voluptatem consequatur velit voluptate', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2022-07-08 17:19:01', '2022-07-08 17:19:01', '', 37, 'http://localhost/wpbasic/?p=38', 0, 'revision', '', 0),
(39, 1, '2022-07-08 17:19:13', '2022-07-08 17:19:13', '<h5>Saepe deleniti cum harum reiciendis</h5>\n\n<hr>\n\n<!--more-->\n<h2>Autem occaecati quo magnam ducimus quae voluptas id. Fugit dolorem veniam error sit quia ullam distinctio numquam. Qui aut quos est eum dolores hic nihil</h2>\n<ul>\n 	<li>Sequi fugiat et sed aut</li>\n 	<li>Et voluptas quasi alias porro ipsam</li>\n 	<li>Sint autem velit omnis</li>\n 	<li>Quam et nostrum</li>\n 	<li>Quis repellat</li>\n</ul>\n<ol>\n 	<li>Hic temporibus aut atque soluta pariatur</li>\n 	<li>Deserunt et at magni in</li>\n 	<li>At facilis soluta unde</li>\n 	<li>Enim aliquam qui ipsum</li>\n</ol>', 'Commodi maiores ut voluptatibus incidunt', 'Quis.', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2022-07-08 17:19:13', '2022-07-08 17:19:13', '', 32, 'http://localhost/wpbasic/?p=39', 0, 'revision', '', 0),
(40, 1, '2022-07-08 17:19:22', '2022-07-08 17:19:22', '<h6>Alias fuga nisi ipsam. Dolorem at odit deserunt omnis. Voluptas consequuntur deleniti quos quos omnis</h6>\n<img alt=\"Autem esse\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/542cb711-4284-3292-8a3c-e2e605c70a99.jpg\">\n<h1>Exercitationem sint nam occaecati. Voluptatem id in quia qui voluptatem ab. Soluta quam sapiente magni a blanditiis facilis. Perferendis nihil eligendi ea quos eum maiores ut</h1>\n<!--more-->\n<ol>\n 	<li>Eveniet atque aut ipsam cumque ab</li>\n 	<li>Dolore quisquam non</li>\n 	<li>Enim maxime non eaque nesciunt in est est</li>\n 	<li>Et perferendis animi molestias aut</li>\n 	<li>Sit rerum accusamus aut nisi esse nulla ducimus</li>\n</ol>\n<h6>Et fuga rerum ducimus voluptatem. Est earum aut et totam. Nam assumenda tempora voluptas maiores quidem nulla</h6>\nEt totam aut explicabo rerum repellat aut. Blanditiis a dignissimos ratione facilis voluptas. facilis officia perspiciatis dolor. Ipsam voluptas minima est voluptatem voluptatem. Quia quis dolor sit quia dolorem ullam. Explicabo qui dicta quam. repudiandae voluptatum repellat fugiat. Et ab <a title=\"Nihil enim.\" href=\"http://www.toy.com/et-est-dolor-et-autem.html\">suscipit</a> aliquam non. Nostrum sequi cupiditate commodi et. Facilis porro doloremque repellendus aut. a sunt rerum itaque vel Ut maxime est aspernatur consequatur Similique ut dolorum cumque possimus. Magnam quis vero nam qui id. Non ipsa eaque tempore. Ipsa voluptatem ullam Quis ea provident incidunt enim expedita. modi in temporibus autem beatae. et ipsa et Nihil quod perferendis quia dolores. asperiores et veritatis quo dolores. similique ut dolore autem eos. sit accusamus rerum. Et assumenda iusto hic. Fugiat laboriosam aliquid eveniet aut est. Non incidunt rerum laudantium. Esse suscipit cum qui id. non cupiditate iste. Mollitia dolores adipisci. Non quis laboriosam a cupiditate et veritatis. Illum ab aliquam dolorem\n<h2>Et consequatur ratione officia impedit</h2>\n<blockquote>Amet iusto <a title=\"Laudantium enim illum aut rerum.\" href=\"https://ryan.com/enim-qui-est-rerum-dicta-libero-aut-animi-quasi.html\">vel</a> sapiente quidem. Molestiae voluptatem ut fugit earum. Sequi ab quas ducimus omnis Qui quis rerum non. Recusandae dolores earum dolorum hic Ipsa aperiam voluptatem voluptatem Impedit reprehenderit dolor qui fuga nobis. Vitae exercitationem sint molestiae Possimus sapiente vel quia commodi. Natus natus aut ex iure placeat non qui. Pariatur repellendus ab enim dolorem. Consequatur <a title=\"Cumque facilis non.\" href=\"http://reinger.com/dolores-exercitationem-tempore-commodi-consectetur\">perspiciatis ipsa. Quam dignissimos</a> ea porro. Eius distinctio blanditiis optio facere. Neque quis ea cupiditate. Et incidunt fugiat et. Dolores iste rerum modi Soluta culpa asperiores autem velit nesciunt. Fugit sed ad dolorem eos <a title=\"Ullam sed.\" href=\"http://okon.com/dolor-ipsam-doloribus-ducimus-voluptas.html\">perspiciatis temporibus. Voluptates</a> blanditiis illum quo debitis aut ut. Quae odio atque qui maiores molestiae. Voluptatem et omnis eaque incidunt.</blockquote>', 'Eum quas neque expedita', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2022-07-08 17:19:22', '2022-07-08 17:19:22', '', 34, 'http://localhost/wpbasic/?p=40', 0, 'revision', '', 0),
(41, 1, '2022-07-09 16:00:55', '2022-07-09 16:00:55', '<h1>Culpa rerum sunt deleniti in qui rem. Consequuntur eum debitis et. Modi autem fugit quaerat ad placeat</h1>\n<ol>\n 	<li>Quasi praesentium</li>\n 	<li>Alias ipsa illo voluptatem</li>\n</ol>\n<h3>Ipsum vitae laborum libero quam. Eum voluptatum nemo asperiores et dicta libero eius aut. Quis fugit culpa saepe excepturi ad explicabo. Nesciunt quam dolor et ut at quia</h3>\n\n<hr>\n\n<h2>Officia doloremque aut deleniti inventore quia sit quia non</h2>\n\n<hr>', 'Soluta eligendi eligendi veniam consequuntur fugiat sint', 'Ut corporis odio.', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2022-07-09 16:00:55', '2022-07-09 16:00:55', '', 18, 'http://localhost/wpbasic/?p=41', 0, 'revision', '', 0),
(42, 1, '2022-07-09 16:07:24', '2022-07-09 16:07:24', '<h4>Nam hic aut consequatur deserunt. Vel dolores blanditiis minus eveniet itaque. Et quod est itaque</h4>\n<img alt=\"Omnis eligendi magni eveniet quod dolorem sunt ipsam\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n\n<hr>\n\n<ol>\n 	<li>Unde rem et ab quod et</li>\n 	<li>Sapiente minus qui</li>\n 	<li>Qui enim maiores vitae optio aliquid</li>\n 	<li>Fuga ea minus laborum qui</li>\n 	<li>Occaecati</li>\n 	<li>Cum qui</li>\n 	<li>Ut vitae sunt quae</li>\n</ol>\n<!--more-->\n<h5>Magni sapiente et quae animi porro natus. Atque ad ea perspiciatis. Velit in qui voluptatem enim</h5>\n<img alt=\"Possimus molestiae amet eum eaque porro ut\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n<ul>\n 	<li>Quia suscipit eveniet voluptatibus</li>\n 	<li>Consequatur repellendus aut iusto omnis</li>\n 	<li>Consequatur est qui quam aut quas</li>\n</ul>', 'Aliquam at ut quae rerum', 'Sed vel consectetur autem.\n\nNemo id rerum.', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2022-07-09 16:07:24', '2022-07-09 16:07:24', '', 16, 'http://localhost/wpbasic/?p=42', 0, 'revision', '', 0),
(43, 1, '2022-07-11 15:28:16', '2022-07-11 15:28:16', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-07-11 15:28:17', '2022-07-11 15:28:17', '', 0, 'http://localhost/wpbasic/?page_id=43', 0, 'page', '', 0),
(44, 1, '2022-07-11 15:28:16', '2022-07-11 15:28:16', '', 'Home', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2022-07-11 15:28:16', '2022-07-11 15:28:16', '', 43, 'http://localhost/wpbasic/?p=44', 0, 'revision', '', 0),
(45, 1, '2022-07-11 15:28:48', '2022-07-11 15:28:48', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2022-07-11 15:28:48', '2022-07-11 15:28:48', '', 0, 'http://localhost/wpbasic/?page_id=45', 0, 'page', '', 0),
(46, 1, '2022-07-11 15:28:48', '2022-07-11 15:28:48', '', 'Services', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-07-11 15:28:48', '2022-07-11 15:28:48', '', 45, 'http://localhost/wpbasic/?p=46', 0, 'revision', '', 0),
(47, 1, '2022-07-11 16:18:21', '2022-07-11 16:18:21', '{\n    \"wpbasic::header_image\": {\n        \"value\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:18:20\"\n    },\n    \"wpbasic::header_image_data\": {\n        \"value\": {\n            \"url\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg\",\n            \"thumbnail_url\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/6e8dec3c-79a4-3b94-98cb-d228337dc848.jpg\",\n            \"timestamp\": 1657556295121,\n            \"attachment_id\": 29,\n            \"width\": 1315,\n            \"height\": 876\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:18:20\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f7bded48-acab-4175-8534-b6090ffcd1eb', '', '', '2022-07-11 16:18:21', '2022-07-11 16:18:21', '', 0, 'http://localhost/wpbasic/?p=47', 0, 'customize_changeset', '', 0),
(48, 1, '2022-07-11 16:20:52', '2022-07-11 16:20:52', '{\n    \"wpbasic::header_image\": {\n        \"value\": \"remove-header\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:18:47\"\n    },\n    \"wpbasic::header_image_data\": {\n        \"value\": \"remove-header\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:18:47\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ae8a8c1f-7f17-4265-aecd-58e9a0a5bb33', '', '', '2022-07-11 16:20:52', '2022-07-11 16:20:52', '', 0, 'http://localhost/wpbasic/?p=48', 0, 'customize_changeset', '', 0),
(49, 1, '2022-07-11 16:21:01', '2022-07-11 16:21:01', '{\n    \"wpbasic::header_image\": {\n        \"value\": \"http://localhost/wpbasic/wp-content/themes/wpbasic/assets/img/vendor-7.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:21:01\"\n    },\n    \"wpbasic::header_image_data\": {\n        \"value\": \"default\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-11 16:21:01\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '75753881-7fa4-448f-bcd6-7c706b44bafa', '', '', '2022-07-11 16:21:01', '2022-07-11 16:21:01', '', 0, 'http://localhost/wpbasic/75753881-7fa4-448f-bcd6-7c706b44bafa/', 0, 'customize_changeset', '', 0),
(50, 1, '2022-07-15 15:43:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-07-15 15:43:10', '0000-00-00 00:00:00', '', 0, 'http://localhost/wpbasic/?p=50', 0, 'post', '', 0),
(51, 1, '2022-07-19 15:47:59', '2022-07-15 15:47:43', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2022-07-19 15:47:59', '2022-07-19 15:47:59', '', 0, 'http://localhost/wpbasic/?p=51', 1, 'nav_menu_item', '', 0),
(53, 1, '2022-07-19 15:47:59', '2022-07-15 16:04:58', '', 'Service 1', '', 'publish', 'closed', 'closed', '', 'service-1', '', '', '2022-07-19 15:47:59', '2022-07-19 15:47:59', '', 0, 'http://localhost/wpbasic/?p=53', 3, 'nav_menu_item', '', 0),
(54, 1, '2022-07-19 15:48:00', '2022-07-15 16:04:58', '', 'Service 2', '', 'publish', 'closed', 'closed', '', 'service-2', '', '', '2022-07-19 15:48:00', '2022-07-19 15:48:00', '', 0, 'http://localhost/wpbasic/?p=54', 4, 'nav_menu_item', '', 0),
(55, 1, '2022-07-15 16:34:04', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-15 16:34:04', '0000-00-00 00:00:00', '', 0, 'http://localhost/wpbasic/?page_id=55', 0, 'page', '', 0),
(56, 1, '2022-07-18 05:20:36', '2022-07-18 05:20:36', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-wpblock', '', '', '2022-07-18 05:20:36', '2022-07-18 05:20:36', '', 0, 'http://localhost/wpbasic/wp-global-styles-wpblock/', 0, 'wp_global_styles', '', 0),
(57, 1, '2022-07-18 05:27:13', '2022-07-18 05:27:13', '<!-- wp:paragraph -->\n<p>Hello</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Heading of the page</h2>\n<!-- /wp:heading -->', 'Index', 'Displays posts.', 'publish', 'closed', 'closed', '', 'index', '', '', '2022-07-18 05:27:13', '2022-07-18 05:27:13', '', 0, 'http://localhost/wpbasic/index/', 0, 'wp_template', '', 0),
(58, 1, '2022-07-19 15:47:59', '2022-07-19 07:48:37', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2022-07-19 15:47:59', '2022-07-19 15:47:59', '', 0, 'http://localhost/wpbasic/?p=58', 2, 'nav_menu_item', '', 0),
(59, 1, '2022-07-19 10:04:24', '2022-07-19 10:04:24', '', 'vendor-7', '', 'inherit', 'open', 'closed', '', 'vendor-7', '', '', '2022-07-19 10:04:24', '2022-07-19 10:04:24', '', 0, 'http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2022-07-19 10:04:30', '2022-07-19 10:04:30', '{\n    \"wpbasic::header_image\": {\n        \"value\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-19 10:04:30\"\n    },\n    \"wpbasic::header_image_data\": {\n        \"value\": {\n            \"url\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\",\n            \"thumbnail_url\": \"http://localhost/wpbasic/wp-content/uploads/2022/07/vendor-7.jpg\",\n            \"timestamp\": 1658225066953,\n            \"attachment_id\": 59,\n            \"width\": 150,\n            \"height\": 50\n        },\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-07-19 10:04:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '438c572e-08c1-4ec4-9613-ccec0fef6554', '', '', '2022-07-19 10:04:30', '2022-07-19 10:04:30', '', 0, 'http://localhost/wpbasic/438c572e-08c1-4ec4-9613-ccec0fef6554/', 0, 'customize_changeset', '', 0),
(61, 1, '2022-07-19 15:46:39', '2022-07-19 15:46:39', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2022-07-19 15:46:41', '2022-07-19 15:46:41', '', 0, 'http://localhost/wpbasic/?page_id=61', 0, 'page', '', 0),
(62, 1, '2022-07-19 15:46:39', '2022-07-19 15:46:39', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2022-07-19 15:46:39', '2022-07-19 15:46:39', '', 61, 'http://localhost/wpbasic/?p=62', 0, 'revision', '', 0),
(63, 1, '2022-07-19 15:47:26', '2022-07-19 15:47:26', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2022-07-19 15:47:26', '2022-07-19 15:47:26', '', 0, 'http://localhost/wpbasic/?page_id=63', 0, 'page', '', 0),
(64, 1, '2022-07-19 15:47:26', '2022-07-19 15:47:26', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2022-07-19 15:47:26', '2022-07-19 15:47:26', '', 63, 'http://localhost/wpbasic/?p=64', 0, 'revision', '', 0),
(65, 1, '2022-07-19 15:48:00', '2022-07-19 15:48:00', ' ', '', '', 'publish', 'closed', 'closed', '', '65', '', '', '2022-07-19 15:48:00', '2022-07-19 15:48:00', '', 0, 'http://localhost/wpbasic/?p=65', 6, 'nav_menu_item', '', 0),
(66, 1, '2022-07-19 15:48:00', '2022-07-19 15:48:00', ' ', '', '', 'publish', 'closed', 'closed', '', '66', '', '', '2022-07-19 15:48:00', '2022-07-19 15:48:00', '', 0, 'http://localhost/wpbasic/?p=66', 5, 'nav_menu_item', '', 0),
(67, 1, '2022-07-19 16:55:33', '2022-07-19 16:55:33', '<h4>Nam hic aut consequatur deserunt. Vel dolores blanditiis minus eveniet itaque. Et quod est itaque</h4>\n<img alt=\"Omnis eligendi magni eveniet quod dolorem sunt ipsam\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n\n<hr>\n\n<ol>\n 	<li>Unde rem et ab quod et</li>\n 	<li>Sapiente minus qui</li>\n 	<li>Qui enim maiores vitae optio aliquid</li>\n 	<li>Fuga ea minus laborum qui</li>\n 	<li>Occaecati</li>\n 	<li>Cum qui</li>\n 	<li>Ut vitae sunt quae</li>\n</ol>\n<!--more-->\n<h5>Magni sapiente et quae animi porro natus. Atque ad ea perspiciatis. Velit in qui voluptatem enim</h5>\n<img alt=\"Possimus molestiae amet eum eaque porro ut\" src=\"http://localhost/wpbasic/wp-content/uploads/2022/07/4884eeba-1ef4-3f06-bbd1-58ab7b59a956.jpg\">\n<ul>\n 	<li>Quia suscipit eveniet voluptatibus</li>\n 	<li>Consequatur repellendus aut iusto omnis</li>\n 	<li>Consequatur est qui quam aut quas</li>\n</ul>', 'Aliquam at ut quae rerum', 'Sed vel consectetur autem.\n\nNemo id rerum.', 'inherit', 'closed', 'closed', '', '16-autosave-v1', '', '', '2022-07-19 16:55:33', '2022-07-19 16:55:33', '', 16, 'http://localhost/wpbasic/?p=67', 0, 'revision', '', 0),
(68, 1, '2022-07-19 16:56:35', '2022-07-19 16:56:35', '<h2>Adipisci sit magnam dolorem odit pariatur et dolorem</h2>\n<ol><li>Quam modi non deserunt quo qui</li><li>Esse atque ex odit molestiae cum</li><li>Rerum voluptas</li><li>Id consequatur aliquid sunt</li><li>Autem aperiam</li></ol>\n<h2>Sit facilis qui veniam aut vel eius. Eos natus et laborum. Sequi expedita maiores dolores vero</h2>\n<p>Itaque provident nulla harum tenetur amet. accusantium autem ut quia. Quas nam consectetur ea Non aut quisquam nostrum ab minima enim. iusto accusamus atque velit expedita dicta. Non qui delectus beatae voluptates. unde commodi quos. Voluptate alias voluptas totam. Quae delectus sint labore asperiores Molestiae blanditiis laboriosam Esse ducimus quam ut quia. Aut ut qui omnis <a title=\"Debitis ea cupiditate alias.\" href=\"http://www.mante.net/totam-optio-quas-dolore-praesentium-eveniet\">Ut repellendus enim eveniet occaecati</a> Dolorem sit laudantium nemo laborum Ut dolor voluptatum laudantium iure ad porro quia. dolorum dolor. Blanditiis rerum assumenda eos id. Eos quam id voluptates at Velit maiores tempore amet non repellendus vero. Rerum doloribus qui dignissimos cumque laboriosam.</p>\n<h1>Dolorem maxime aliquid in et nesciunt. Tenetur quibusdam voluptas similique sint nisi. Dolores fuga repellendus quae impedit. Autem dignissimos asperiores nisi dolorum et aliquid</h1>\n<p>Eum voluptates aut aut quibusdam neque. Nulla voluptas recusandae dolor alias. Sed in unde quos dicta.</p>\n<ul><li>Tempora et quae a ut est</li><li>Dolorem consequatur dolore accusantium</li><li>Et nostrum quasi porro quis quasi</li><li>Alias fuga</li></ul>\n<h1>Voluptates suscipit deleniti repudiandae eum. Numquam saepe quia beatae blanditiis quibusdam. Cupiditate dolorum molestias pariatur mollitia itaque dolores corrupti. Enim dolor facilis aut</h1>\n<ul><li>Cupiditate autem blanditiis ut quibusdam voluptatibus</li><li>Laborum ea vel ex</li><li>Voluptatem ut dignissimos culpa</li><li>Nam sed nostrum vitae distinctio</li><li>Laudantium</li><li>Voluptas corporis quos aut</li><li>Ad nemo ut sequi ut et minima</li></ul>\n<h1>Expedita tempore molestiae hic illum porro omnis. Et soluta molestiae sequi. Eveniet quo excepturi distinctio nostrum itaque</h1>\n<blockquote>Non porro et et <a title=\"Et magni a qui nobis vitae dolores numquam voluptatem sunt laborum.\" href=\"https://www.haag.org/illo-dolorem-voluptatem-qui-assumenda-et-eos\">placeat.</a> eos <a title=\"Reiciendis sapiente ipsum quia autem vel.\" href=\"http://www.cormier.net/\">illum</a> occaecati. Ea nihil ullam exercitationem aut culpa. At magnam aut dolores omnis quia. Qui iusto qui porro tenetur voluptates similique</blockquote>\n<hr>', 'Omnis incidunt sapiente et autem qui modi', 'Sed soluta enim.\n\nQuos laboriosam non.', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-07-19 16:56:35', '2022-07-19 16:56:35', '', 35, 'http://localhost/wpbasic/?p=68', 0, 'revision', '', 0),
(69, 1, '2022-07-20 16:41:25', '0000-00-00 00:00:00', '', 'Terms & Condition', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-07-20 16:41:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/wpbasic/?p=69', 1, 'nav_menu_item', '', 0),
(70, 1, '2022-07-20 16:41:34', '0000-00-00 00:00:00', '', 'Privacy Policy', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-07-20 16:41:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/wpbasic/?p=70', 1, 'nav_menu_item', '', 0),
(71, 1, '2022-07-20 16:41:43', '0000-00-00 00:00:00', '', 'Learn About More', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-07-20 16:41:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/wpbasic/?p=71', 1, 'nav_menu_item', '', 0),
(72, 1, '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 'Terms & Condition', '', 'publish', 'closed', 'closed', '', 'terms-condition', '', '', '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 0, 'http://localhost/wpbasic/?p=72', 1, 'nav_menu_item', '', 0),
(73, 1, '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 'Learn About More', '', 'publish', 'closed', 'closed', '', 'learn-about-more', '', '', '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 0, 'http://localhost/wpbasic/?p=73', 2, 'nav_menu_item', '', 0),
(74, 1, '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 0, 'http://localhost/wpbasic/?p=74', 3, 'nav_menu_item', '', 0),
(75, 1, '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 'All Services', '', 'publish', 'closed', 'closed', '', 'all-services', '', '', '2022-07-20 16:42:53', '2022-07-20 16:42:53', '', 0, 'http://localhost/wpbasic/?p=75', 4, 'nav_menu_item', '', 0),
(76, 1, '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 'Our Vision', '', 'publish', 'closed', 'closed', '', 'our-vision', '', '', '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 0, 'http://localhost/wpbasic/?p=76', 1, 'nav_menu_item', '', 0),
(77, 1, '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 'Working Process', '', 'publish', 'closed', 'closed', '', 'working-process', '', '', '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 0, 'http://localhost/wpbasic/?p=77', 2, 'nav_menu_item', '', 0),
(78, 1, '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 'Dealing System', '', 'publish', 'closed', 'closed', '', 'dealing-system', '', '', '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 0, 'http://localhost/wpbasic/?p=78', 3, 'nav_menu_item', '', 0),
(79, 1, '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 'Team Member', '', 'publish', 'closed', 'closed', '', 'team-member', '', '', '2022-07-20 17:01:37', '2022-07-20 17:01:37', '', 0, 'http://localhost/wpbasic/?p=79', 4, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_termmeta`
--

CREATE TABLE `wpbasic_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_terms`
--

CREATE TABLE `wpbasic_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_terms`
--

INSERT INTO `wpbasic_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'wpbasic', 'wpbasic', 0),
(3, 'Sports', 'sports', 0),
(4, 'Cricket', 'cricket', 0),
(5, 'Bangladesh', 'bangladesh', 0),
(6, 'Youtube', 'youtube', 0),
(7, 'Facebook', 'facebook', 0),
(8, 'Twitter', 'twitter', 0),
(9, 'main menu', 'main-menu', 0),
(10, 'wpblock', 'wpblock', 0),
(11, 'News', 'news', 0),
(12, 'Wordpress Theme', 'wordpress-theme', 0),
(13, 'Elementor', 'elementor', 0),
(14, 'Sakib Al Hasan', 'sakib-al-hasan', 0),
(15, 'Tamim Iqbal', 'tamim-iqbal', 0),
(16, 'Footer Menu', 'footer-menu', 0),
(17, 'Footer Menu 2', 'footer-menu-2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_term_relationships`
--

CREATE TABLE `wpbasic_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_term_relationships`
--

INSERT INTO `wpbasic_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 2, 0),
(13, 1, 0),
(16, 1, 0),
(16, 5, 0),
(16, 6, 0),
(16, 12, 0),
(16, 13, 0),
(18, 3, 0),
(18, 4, 0),
(18, 7, 0),
(18, 8, 0),
(20, 1, 0),
(22, 1, 0),
(23, 1, 0),
(25, 1, 0),
(27, 1, 0),
(30, 1, 0),
(32, 1, 0),
(34, 1, 0),
(34, 14, 0),
(35, 1, 0),
(35, 15, 0),
(37, 1, 0),
(37, 11, 0),
(37, 13, 0),
(51, 9, 0),
(53, 9, 0),
(54, 9, 0),
(56, 10, 0),
(57, 10, 0),
(58, 9, 0),
(65, 9, 0),
(66, 9, 0),
(72, 16, 0),
(73, 16, 0),
(74, 16, 0),
(75, 16, 0),
(76, 17, 0),
(77, 17, 0),
(78, 17, 0),
(79, 17, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_term_taxonomy`
--

CREATE TABLE `wpbasic_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_term_taxonomy`
--

INSERT INTO `wpbasic_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 12),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'category', '', 0, 1),
(4, 4, 'category', '', 0, 1),
(5, 5, 'post_tag', '', 0, 1),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'nav_menu', '', 0, 6),
(10, 10, 'wp_theme', '', 0, 2),
(11, 11, 'category', '', 0, 1),
(12, 12, 'category', '', 0, 1),
(13, 13, 'category', '', 0, 2),
(14, 14, 'post_tag', '', 0, 1),
(15, 15, 'post_tag', '', 0, 1),
(16, 16, 'nav_menu', '', 0, 4),
(17, 17, 'nav_menu', '', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_usermeta`
--

CREATE TABLE `wpbasic_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_usermeta`
--

INSERT INTO `wpbasic_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'wpbasic'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wpbasic_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wpbasic_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"2cb6bd5118c68262795011380fda6c0232b4a79d6a9170de516a479ae9ebd431\";a:4:{s:10:\"expiration\";i:1658504370;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:80:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0\";s:5:\"login\";i:1657294770;}s:64:\"35e79e05a6e384ad7e88ce267dd41d33aec23d4c68bd611718f294bb3188672c\";a:4:{s:10:\"expiration\";i:1659109385;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36\";s:5:\"login\";i:1657899785;}}'),
(17, 1, 'wpbasic_dashboard_quick_press_last_post_id', '50'),
(18, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(19, 1, 'metaboxhidden_dashboard', 'a:5:{i:0;s:21:\"dashboard_site_health\";i:1;s:19:\"dashboard_right_now\";i:2;s:18:\"dashboard_activity\";i:3;s:21:\"dashboard_quick_press\";i:4;s:17:\"dashboard_primary\";}'),
(20, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(21, 1, 'managenav-menuscolumnshidden', 'a:2:{i:0;s:3:\"xfn\";i:1;s:11:\"description\";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(23, 1, 'wpbasic_user-settings', 'libraryContent=browse&posts_list_mode=list'),
(24, 1, 'wpbasic_user-settings-time', '1658249687'),
(25, 2, 'nickname', 'mohammadarif'),
(26, 2, 'first_name', 'Mohammad'),
(27, 2, 'last_name', 'Arif'),
(28, 2, 'description', ''),
(29, 2, 'rich_editing', 'true'),
(30, 2, 'syntax_highlighting', 'true'),
(31, 2, 'comment_shortcuts', 'false'),
(32, 2, 'admin_color', 'fresh'),
(33, 2, 'use_ssl', '0'),
(34, 2, 'show_admin_bar_front', 'true'),
(35, 2, 'locale', ''),
(36, 2, 'wpbasic_capabilities', 'a:1:{s:6:\"editor\";b:1;}'),
(37, 2, 'wpbasic_user_level', '7'),
(38, 2, 'dismissed_wp_pointers', ''),
(39, 1, 'nav_menu_recently_edited', '17'),
(40, 1, 'edit_post_per_page', '30');

-- --------------------------------------------------------

--
-- Table structure for table `wpbasic_users`
--

CREATE TABLE `wpbasic_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpbasic_users`
--

INSERT INTO `wpbasic_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'wpbasic', '$P$BSgEh/dM8EWvaP/DKMq92qpewwAA3J/', 'wpbasic', 'parvezsani191@gmail.com', 'http://localhost/wpbasic', '2022-07-08 15:39:17', '', 0, 'wpbasic'),
(2, 'mohammadarif', '$P$Bh9QzN9KeHwsrheXETBCOLFGLe.1eo0', 'mohammadarif', 'mohammadarif@gmail.com', '', '2022-07-18 14:01:51', '1658152911:$P$BPa4rUDlrqJXb4cf/onT9S.Qjg/ibx1', 0, 'Mohammad Arif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wpbasic_commentmeta`
--
ALTER TABLE `wpbasic_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpbasic_comments`
--
ALTER TABLE `wpbasic_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wpbasic_links`
--
ALTER TABLE `wpbasic_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wpbasic_options`
--
ALTER TABLE `wpbasic_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wpbasic_postmeta`
--
ALTER TABLE `wpbasic_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpbasic_posts`
--
ALTER TABLE `wpbasic_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wpbasic_termmeta`
--
ALTER TABLE `wpbasic_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpbasic_terms`
--
ALTER TABLE `wpbasic_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wpbasic_term_relationships`
--
ALTER TABLE `wpbasic_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wpbasic_term_taxonomy`
--
ALTER TABLE `wpbasic_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wpbasic_usermeta`
--
ALTER TABLE `wpbasic_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpbasic_users`
--
ALTER TABLE `wpbasic_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wpbasic_commentmeta`
--
ALTER TABLE `wpbasic_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpbasic_comments`
--
ALTER TABLE `wpbasic_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpbasic_links`
--
ALTER TABLE `wpbasic_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpbasic_options`
--
ALTER TABLE `wpbasic_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=779;

--
-- AUTO_INCREMENT for table `wpbasic_postmeta`
--
ALTER TABLE `wpbasic_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `wpbasic_posts`
--
ALTER TABLE `wpbasic_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `wpbasic_termmeta`
--
ALTER TABLE `wpbasic_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpbasic_terms`
--
ALTER TABLE `wpbasic_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wpbasic_term_taxonomy`
--
ALTER TABLE `wpbasic_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wpbasic_usermeta`
--
ALTER TABLE `wpbasic_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `wpbasic_users`
--
ALTER TABLE `wpbasic_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
